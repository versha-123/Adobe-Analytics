
google.load("visualization", "1", {packages:["corechart"]});
//google.setOnLoadCallback(drawChart);
	  
	 
function drawChart(events, chartDivID, chartTitle) {
    var newData= events; //JSON.parse(records);
	console.log(newData);
    var result = [];
    result.push(['errorcode', 'workflow_count']);
    
    for(var i = 0; i < newData.length; i++){
        result.push([newData[i].errorcode, parseInt(newData[i].workflow_count)]);
    }

    var data = google.visualization.arrayToDataTable(result);  
		
    var options = {
      title: chartTitle,
      is3D: true,
      sliceVisibilityThreshold: .01,
      //backgroundColor: '#CEE3F6'
    };

    var chart = new google.visualization.PieChart(document.getElementById(chartDivID));
    chart.draw(data, options);
    document.getElementById(chartDivID);

}

function drawLineChart(x_axis, y_axis,legend_name, chartDivID, chartTitle) {

    var result = [];
    result.push(['x_axis_data', legend_name]); 
    
    for(var i = 0; i < x_axis.length && i < y_axis.length; i++){
        var tempDate = x_axis[i].substr(5).replace("-","/");
        result.push([tempDate, parseInt(y_axis[i])]);  
    }

    var data = google.visualization.arrayToDataTable(result);  
		
    var options = {
      title: chartTitle,
      //curveType: 'function',
      legend: { position: 'right' }
      //backgroundColor: '#CEE3F6'
    };

    var chart = new google.visualization.LineChart(document.getElementById(chartDivID));
    chart.draw(data, options);
    document.getElementById(chartDivID);

}