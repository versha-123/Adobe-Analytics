var dashboard = angular.module('dashboard', ['ngRoute', 'smart-table', 'chart.js','ng-fusioncharts']);
var thorBuilds = ["4.7.0.400","4.6.1.393","4.6.0.384", "4.5.0.331" ,"4.4.1.298", "4.3.0.256","4.2.0.211","4.1.1.202","4.0.1.188","3.9.1.335","3.8.0.310","3.7.0.272", "3.6.0.248","3.5.1.209", "3.4.1.181", "3.3.0.151"];
var thorBuildsForThorSuccess = ["4.7.0.400","4.6.1.393","4.6.0.384", "4.5.0.331" ,"4.4.1.298", "4.3.0.256","4.2.0.211","4.1.1.202","4.0.1.188","3.9.1.335","3.8.0.310","3.7.0.272", "3.6.0.248","3.5.1.209", "3.4.1.181", "3.3.0.151"];

var thorBuildsForHostFileFix = ["4.7.0.400","4.6.1.393","4.6.0.384", "4.5.0.331" ,"4.4.1.298", "4.4.0.294","4.3.0.256","4.2.0.211","4.1.1.202","4.1.0.%","4.0.1.188","4.0.0.185", "3.9.5.353","3.9.1.335","3.9.0.334","3.8.0.310","3.7.5.291","3.7.0.272"];
var thorBuildsForNotificationBadging = ["3.9.1.335","3.8.0.310"];
var ThorPanelVisitReleases = ["4.7.0.400","4.7.0.%","4.6.1.393","4.6.0.384", "4.5.0.331" ,"4.4.1.298", "4.3.0.256","4.2.0.211","4.1.1.202","4.0.1.188","3.9.1.335","3.8.0.310","3.7.0.272", "3.6.0.248","3.5.1.209", "3.4.1.181", "3.3.0.151"];

var thorReleasesForHDUpdates = ["4.7.0.400","4.7.0.%","4.6.1.393","4.6.0.391","4.6.0.384", "4.5.0.331" ,"4.4.1.298", "4.4.0.294","4.3.0.256","4.2.0.211","4.1.1.202","4.1.0.%","4.0.1.188","4.0.0.185", "3.9.5.353","3.9.1.335"];
var hdThorReleases = ["4.7.0.400","4.7.0.%","4.6.0.391","4.6.0.384", "4.5.0.331" ,"4.4.1.298", "4.4.0.294","4.3.0.256","4.2.0.211","4.1.1.202","4.0.1.188","4.0.0.185", "3.9.5.353","3.9.1.335","3.9.0.334","3.8.0.310","3.7.5.291","3.7.0.272","3.6.0.248","3.5.1.209","3.4.1.181"];
var hdResourceErrorReleases = ["4.7.0.400","4.7.0.%","4.6.0.384", "4.5.0.331" ,"4.4.1.298", "4.4.0.294","4.3.0.256"];
var thorBuildsForMiscEvents = ["4.7.0.400","4.6.1.393","4.6.0.384", "4.5.0.331" ,"4.4.1.298", "4.4.0.294","4.3.0.256","4.2.0.211","4.1.1.202","4.1.0.%","4.0.1.188"];
//This should be in descending order for latest to be shown
var thorReleases = ["FEB 2016", "NOV 2015", "MAX 2015", "CC 2015"];
var kaizenReleases = ["3.9.6.362", "3.9.6.361", "3.8.0.318", "3.7.0.270", "3.6.0.222", "3.8.0.310"];
var kaizenProducts = ["ALL", "ILST", "PHSP", "SPRK", "APRO", "PPRO", "AEFT", "AME", "PRLD", "AUDT", "FLPR", "KBRG", "IDSN", "AICY",  "DRWV", "MUSE","RUSH"];

var thorInstallationSteps = ["THOR","PRODUCT"];
var platforms = ["Win", "Mac"];
var environment = "local";
var hostMac;
var CoreSyncReleases = ["4.0.1","3.0.3","3.0.2","2.4.6","2.4.4","2.4.3","2.4.2", "2.4.1"];
var CCXReleases = ["2.5.1","2.2.1"];
var CCLibraryReleases = ["3.0.13","3.0","2.14.9","2.14.8","2.14.7"];
var autoUpdateProducts =["All","ACR","AEFT","AICY","AME","AUDT","CHAR","DRWV","ESHR","FLPR","IDSN","ILST","KBRG","LRCC","LTRM","PHSP","PPRO","PRLD","SPRK"];
//var autoUpdateProducts = ["ALL", "ILST", "PHSP", "SPRK", "APRO", "PPRO", "AEFT", "AME", "PRLD", "AUDT", "FLPR", "KBRG", "IDSN", "AICY",  "DRWV", "MUSE"];
var thorReleasesForAutoUpdates = ["4.7.0.400"];

if(environment == "production"){
    hostMac = "http://10.41.37.161:3000"
}else if(environment == "stage"){
    hostMac = "http://10.42.84.200:3000"
}else if(environment == "local"){
    hostMac = "http://10.42.39.218:3000"
}else{
    console.log("Not a valid environment")
}

var hedrs = {
    headers: {
        'Accept': 'application/json'
    }
};

var createCookie = function(name,value,days) {
    if (days) {
        var date = new Date();
        date.setTime(date.getTime()+(days*24*60*60*1000));
        var expires = "; expires="+date.toGMTString();
    }
    else var expires = "";
    document.cookie = name+"="+value+expires+"; path=/";
}

var readCookie = function(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}

var eraseCookie = function(name) {
    createCookie(name,"",-1);
}

dashboard.config(function($routeProvider, $httpProvider){
    $routeProvider
        .when('/',{
            templateUrl: 'pages/home.html',
            controller: 'homeController'
        })

        .when('/home',{
            templateUrl: 'pages/home.html',
            controller: 'homeController'
        })
        
        .when('/login',{
            templateUrl: 'pages/login.html',
            controller: 'loginController'
        })
        
        .when('/logout',{
            templateUrl: 'pages/logout.html',
            controller: 'logoutController'
        })
    
        .when('/thor_success',{
            templateUrl: 'pages/thor_success.html',
            controller: 'thorSuccessController'
        })
        .when('/auto_update',{
            templateUrl: 'pages/auto_update.html',
            controller: 'autoUpdateController'
        })
        
//        .when('/thor_success_details',{
//            templateUrl: 'pages/thor_success_details.html',
//            controller: 'thorSuccessDetailsController'
//        })
    
		.when('/thor_errors',{
            templateUrl: 'pages/thor_errors.html',
            controller: 'thorErrorController'
        })

		.when('/thor_misc_events',{
            templateUrl: 'pages/thor_misc_events.html',
            controller: 'thorMiscEventsController'
        })
        
//        .when('/thor_errors_details',{
//            templateUrl: 'pages/thor_errors_details.html',
//            controller: 'thorErrorDetailsController'
//        })
        
        .when('/thor_errors151',{
            templateUrl: 'pages/thor_errors151.html',
            controller: 'thorError151Controller'
        })
            
        .when('/thor_success_compare',{
            templateUrl: 'pages/thor_success_compare.html',
            controller: 'thorSuccessCompareController'
        })
        
        .when('/thor_success_compare151',{
            templateUrl: 'pages/thor_success_compare.html',
            controller: 'thorSuccessCompare151Controller'
        })
    
        .when('/panels_visit',{
            templateUrl: 'pages/panels_visit.html',
            controller: 'panelsVisitController'
        })
        
        .when('/hd_success',{
            templateUrl: 'pages/hd_success.html',
            controller: 'hdSuccessController'
        })
        
        .when('/hd_errors',{
            templateUrl: 'pages/hd_errors.html',
            controller: 'hdErrorController'
        })
    .when('/hd2_errors',{
            templateUrl: 'pages/hd2_errors.html',
            controller: 'hd2ErrorController'
        })
    .when('/hd2_resource_errors',{
            templateUrl: 'pages/hd2_resource_errors.html',
            controller: 'hd2ResourceErrorController'
        })
     .when('/hd2_errors_productwise',{
            templateUrl: 'pages/hd2_errors_productwise.html',
            controller: 'hd2ErrorProductWiseController'
        })
     .when('/hd2_updates_errors',{
            templateUrl: 'pages/hd2_updates_errors.html',
            controller: 'hd2UpdatesErrorController'
        })    
	 .when('/hd2_updates_success',{
            templateUrl: 'pages/hd2_updates_success.html',
            controller: 'hd2UpdatesSuccessController'
        })        
        .when('/hd_success_compare',{
            templateUrl: 'pages/hd_success_compare.html',
            controller: 'hdSuccessCompareController'
        })
        .when('/hd_details',{
            templateUrl: 'pages/hd_details.html',
            controller: 'hdSuccessDetailsController'
        })
    
        .when('/forums',{
            templateUrl: 'pages/forums.html',
            controller: 'forumsController'
        })
        .when('/max_18',{
            templateUrl: 'pages/max_18.html',
            controller: 'max_18Controller'
        })
    
        
        .when('/thor_carousel',{
            templateUrl: 'pages/home.html',
            controller: 'homeController'
        })
        
        .when('/conf_percent',{
            templateUrl: 'pages/conf_percent.html',
            controller: 'confPercentController'
        })
        
        .when('/conf_percent_v2',{
            templateUrl: 'pages/conf_percent_v2.html',
            controller: 'confPercentV2Controller'
        })
    
        .when('/conf_process',{
            templateUrl: 'pages/conf_process.html',
            controller: 'confProcessController'
        })
        
        .when('/ccapps_success',{
            templateUrl: 'pages/ccapps_success.html',
            controller: 'ccappsSuccessController'
        })
        
        .when('/ccapps_errors',{
            templateUrl: 'pages/ccapps_errors.html',
            controller: 'ccappsErrorController'
        })
        
        .when('/ccapps_details',{
            templateUrl: 'pages/ccapps_details.html',
            controller: 'ccappsDetailsController'
        })
    
        .when('/product_summary',{
            templateUrl: 'pages/product_summary.html',
            controller: 'productSummaryController'
        })
        
        .when('/product_errors',{
            templateUrl: 'pages/product_errors.html',
            controller: 'productErrorsController'
        })
        
        .when('/products_size',{
            templateUrl: 'pages/products_size.html',
            controller: 'productsSizeController'
        })
                            
        .when('/hd_ribs_ai',{
            templateUrl: 'pages/ribs_hd_AI.html',
            controller: 'ribsHdAIController'
        })
    
        .when('/crash_report',{
            templateUrl: 'pages/crash_report.html',
            controller: 'crashReportController'
        })
        
        .when('/products_monthly_detail',{
            templateUrl: 'pages/products_monthly_detail.html',
            controller: 'productsMonthlyDetailController'
        })
        
        .when('/funnel_charts',{
            templateUrl: 'pages/funnel_charts.html',
            controller: 'funnelController'
        })
    
        .when('/kaizen_success',{
            templateUrl: 'pages/kaizen_success.html',
            controller: 'kaizenSuccessController'
        })
        .when('/kaizen_errors',{
            templateUrl: 'pages/kaizen_errors.html',
            controller: 'kaizenErrorController'
        })
    .when('/kaizen_details',{
            templateUrl: 'pages/kaizen_details.html',
            controller: 'kaizenDetailsController'
        })
    .when('/host_file_fix',{
            templateUrl: 'pages/host_file_fix.html',
            controller: 'hostFileFix'
        })
     .when('/Notifications_Badging',{
            templateUrl: 'pages/Notifications_Badging.html',
            controller: 'NotificationsBadging'
        })
    .when('/Campaign_Analytics',{
            templateUrl: 'pages/Campaign_Analytics.html',
            controller: 'CampaignAnalytics'
        })
    .when('/hd2_success',{
            templateUrl: 'pages/hd2_success.html',
            controller: 'hd2SuccessController'
        })
    .when('/hd3_success',{
            templateUrl: 'pages/hd3_success.html',
            controller: 'hd3SuccessController'
        })
    .when('/CoreSync',{
            templateUrl: 'pages/CoreSync.html',
            controller: 'coreSyncController'
        })
    .when('/CCX',{
            templateUrl: 'pages/CCX.html',
            controller: 'ccxController'
        })
    .when('/CCLibrary',{
        templateUrl: 'pages/CCLibrary.html',
        controller: 'cclibraryController'
    })
        .otherwise({
           redirectTo: '/home'
        });
    
    //This is required for $http post calls, angular sends the body data as json instead of urlencoded params
    $httpProvider.defaults.transformRequest = function(data){
        if (data === undefined) {
            return data;
        }
        return $.param(data);
    }
});

//This is for spying over the route changes, for user to move to login page.
dashboard.run(function($rootScope, $location) {
    $rootScope.$on( "$routeChangeStart", function(event, next, current) {
        if ($rootScope.loggedInUser == null) {
            var x = readCookie('thorAnalytics');
            if (x) {
                $rootScope.loggedInUser = x;
                $rootScope.isUserloggedIn = true;
            }
        }
        if ($rootScope.loggedInUser == null) {
            $rootScope.previousRouteTemplate = current.templateUrl;
            // no logged user, redirect to /login
            if (next.templateUrl==="pages/forums.html") {
            }
            else if (next.templateUrl==="pages/login.html" || next.templateUrl==="pages/home.html" || next.redirectTo==='/') {
            } 
            else {
              $location.path("/login");
            }
        }
    });
});

dashboard.controller('homeController', function($scope, $http, $filter, $location, $anchorScroll) {
    console.log("Inside home controller");
});

dashboard.controller('loginController', function($scope, $http, $filter, $location, $anchorScroll, $rootScope) {
    console.log("Inside login controller");
    $scope.loginUserModel = {}
    
    $scope.login =function(){
        console.log($scope.loginUserModel);
        console.log($scope.loginUserModel.email);
        console.log($scope.loginUserModel.password);
        
        var requestData = {
            email: $scope.loginUserModel.email,
            password: $scope.loginUserModel.password
        };
        
        //Now we need to validate the user via server
        $http({
            method: 'POST',
            url: hostMac+"/api/login",
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            data: requestData
        })
        .success(function (response) {
            console.log(response)
            if(response.success){
                $rootScope.loggedInUser = $scope.loginUserModel.email;
                $rootScope.isUserloggedIn = true;
                $location.path( "/home" );
                createCookie('thorAnalytics',$scope.loginUserModel.email,365);
            }else {
                $scope.loginError = "Invalid user id/password.";
            }
        });
    }
    
});

dashboard.controller('logoutController', function($scope, $http, $filter, $location, $anchorScroll, $rootScope) {
    $scope.logout = function(){
        eraseCookie('thorAnalytics');
        $rootScope.loggedInUser = null;
        $rootScope.isUserloggedIn = false;
        $location.path("/home");   
    }
    $scope.cancel = function(){
        $location.path($rootScope.previousRouteTemplate);
    }
});

dashboard.controller('logoutController', function($scope, $http, $filter, $location, $anchorScroll, $rootScope) {
    $scope.logout = function(){
        eraseCookie('thorAnalytics');
        $rootScope.loggedInUser = null;
        $rootScope.isUserloggedIn = false;
        $location.path("/home");   
    }
    $scope.cancel = function(){
        $location.path($rootScope.previousRouteTemplate);
    }
});

dashboard.controller('autoUpdateController', function($scope, $http, $filter, $location, $anchorScroll, $rootScope) {
    $scope.autoUpdateBuildList = thorReleasesForAutoUpdates;
    $scope.selectedBuild = $scope.autoUpdateBuildList[0];
    $scope.autoUpdateProductList = autoUpdateProducts;
    $scope.selectedProduct = $scope.autoUpdateProductList[2];
    
    
    $scope.getDataFromServer = function(buildNumber,product){
        $http.get(hostMac+"/api/auto_update_report?buildNumber=" + buildNumber+"&product="+product, hedrs)
        .success(function (response) {
            $scope.autoUpdateDialogShown=response.autoUpdateDialogShown;
            $scope.aUOverallOnboarded=response.aUOverallOnboarded;
            $scope.aUOnboardedSourceNFD=response.aUOnboardedSourceNFD;
            $scope.aUDropOutNFD=response.aUDropOutNFD;
            $scope.aUDropOutAYS=response.aUDropOutAYS;
            
            $scope.onboardedSourceNFDPercentage=($scope.aUOnboardedSourceNFD/$scope.aUOverallOnboarded)*100
            $scope.aUOnboardedSourceConfigDialog=response.aUOnboardedSourceConfigDialog;
            $scope.build_number = response.build_number;
            $scope.time = response.time;            
            $scope.labels = ['Overall','Download', 'Install', 'Total' ];
            $scope.preReleaseData = response.preReleaseData;
            $scope.dateWiseToSend=response.dateWiseToSend;
            //$scope.data = $scope.updateChart($scope.all, $scope.freshInstall, $scope.selfUpdateInstall, $scope.autoUpdateInstall);
        });
    };
    //debugger;
    
    $scope.getDataFromServer($scope.selectedBuild,$scope.selectedProduct);
    $scope.getBuildData = function($event){
        $scope.selectedBuild = ($($event.target).html()).trim();
        $scope.getDataFromServer(($scope.selectedRelease).trim(), ($scope.selectedProduct).trim());
    };
    
    $scope.getProductData = function($event) {
        $scope.selectedProduct = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedBuild).trim(), ($scope.selectedProduct).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = [ "We are using ETS as the database to gather this information",
                        "This is based on lbsworkfFlowID, i.e. it is based on distinct workflows", 
                        "We are using the build number to ascertain the range, not time frame",                     
                        "Download Success = No of Download end/Download Started", 
                        "Install Success = No of install end/ Install Started" ,
                        "Thor Success = No of Install End/ Download Started" ,
                        "Thor Cancellation = Number of PIM_STATUS_DOWNLOAD_CANCELED / Download Started", 
                        "Thor Success (Net of Cancel) = No of install end / (Download Started-Cancellation) "]
    
   
});

dashboard.controller('thorSuccessController', function($rootScope, $scope, $http, $filter, $location, $anchorScroll) {
	$scope.thorBuildsList = thorBuildsForThorSuccess;
    $scope.selectedBuild = $scope.thorBuildsList[0]

    $scope.updateChart = function(freshInstall, selfUpdateInstall, autoUpdateInstall){
        var data = [
            [freshInstall.download_success, freshInstall.install_success, freshInstall.thor_success, freshInstall.net_of_cancel, freshInstall.net_success],
            [selfUpdateInstall.download_success, selfUpdateInstall.install_success, selfUpdateInstall.thor_success, selfUpdateInstall.net_of_cancel, selfUpdateInstall.net_success],
            [autoUpdateInstall.download_success, autoUpdateInstall.install_success, autoUpdateInstall.thor_success, autoUpdateInstall.net_of_cancel, autoUpdateInstall.net_success]
          ];
        return data;
    }
    
    $scope.getDataFromServer = function(buildNumber){
        $http.get(hostMac+"/api/accsuccess?buildNumber=" + buildNumber, hedrs)
        .success(function (response) {
            $scope.build_number = response.build_number
            $scope.time = response.time            
            $scope.all = response.all;
            $scope.freshInstall = response.fresh;
            $scope.repair = response.repair;
            $scope.Wam = response.Wam;
            $scope.wam_update = response.wam_update;
            $scope.selfUpdateInstall = response.self_update;
            $scope.selfUpdatefreshInstall = response.self_update_fresh;
            $scope.autoUpdateInstall = response.auto_update;
            $scope.bootstrapEvents = response.bootstrap_events;
            $scope.labels = ['Overall','Download', 'Install', 'Total' ];
            $scope.series = ['Overall','Fresh','Repair','Kaizen','Kaizen-Update','Self-Update', 'Auto-Update'];
            $scope.preReleaseData = response.preReleaseData;
            //$scope.data = $scope.updateChart($scope.all, $scope.freshInstall, $scope.selfUpdateInstall, $scope.autoUpdateInstall);
        });
    };
    $scope.getDataFromServer($scope.selectedBuild);
    $scope.isSUOverFreshEnabled = function()
    {
        if( $scope.build_number >= '3.9.5' )
            return true;
        else
            return false;
    };
    
    $scope.isWamUpdateEnabled = function()
    {
        if( $scope.build_number >= '4.6' )
            return true;
        else
            return false;
    };
    
    $scope.iskaizenEnabled = function()
    {
        if( $scope.Wam.download_success != 0 )
                return true;
            else
                return false;
    };
    
    $scope.isRepairEnabled = function()
    {
        if( $scope.build_number >= '4.0' )
                return true;
            else
                return false;
    };
    
    $scope.shouldNameToBeShow = function(name)
    {
        if(name == 'Repair')
        {
            if( $scope.build_number >= '4.0' )
                return true;
            else
                return false;
        }
        else if(name == 'Kaizen-Update')
        {
            if( $scope.build_number >= '4.6' )
                return true;
            else
                return false;
        }
        else if(name == 'LBS-Update')
        {
            if( $scope.build_number >= '3.9.5' )
                return true;
            else
                return false;
        }
        else if(name == 'kaizen')
        {
            if( $scope.Wam.download_success != 0 )
                return true;
            else
                return false;
        }

        return true;
    };
    
    $scope.getBuildData = function($event){
        $scope.selectedBuild = ($($event.target).html()).trim();
        $scope.getDataFromServer(($scope.selectedBuild).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = [ "We are using ETS as the database to gather this information",
                        "This is based on lbsworkfFlowID, i.e. it is based on distinct workflows", 
                        "We are using the build number to ascertain the range, not time frame",                     
                        "Download Success = No of Download end/Download Started", 
                        "Install Success = No of install end/ Install Started" ,
                        "Thor Success = No of Install End/ Download Started" ,
                        "Thor Cancellation = Number of PIM_STATUS_DOWNLOAD_CANCELED / Download Started", 
                        "Thor Success (Net of Cancel) = No of install end / (Download Started-Cancellation) "]
    
   
});

dashboard.controller('thorErrorController', function($rootScope,$scope, $http, $filter, $location, $anchorScroll) {
    var allEvents;
    $scope.thorBuildsList = thorBuilds;
    $scope.selectedBuild = $scope.thorBuildsList[0]
    $scope.installModesList = ["All", "Fresh","Repair","kaizen", "Auto-Update", "Self-Update","LBS-Update"]; //
    $scope.selectedInstallMode = $scope.installModesList[0]
    
    $scope.getOverallDataFromServer = function(buildNumber){
        $http.get(hostMac+"/api/accsuccess?buildNumber=" + buildNumber, hedrs)
        .success(function (response) {            
            $scope.all = response.all;
            $scope.fresh = response.fresh;
            $scope.repair = response.repair;
            $scope.Wam = response.Wam;
            $scope.self_update = response.self_update;
            $scope.auto_update = response.auto_update;
            $scope.lbs_update = response.self_update_fresh;
            $scope.getDataFromServer(buildNumber, $scope.selectedInstallMode);
        });
    };
    $scope.getOverallDataFromServer($scope.selectedBuild);
    
    $scope.getDataFromServer = function(buildNumber, installMode){
        $http.get(hostMac+"/api/accerrors?buildNumber="+buildNumber, hedrs)
        .success(function (response) {
            $scope.build_number = response.build_number;
            $scope.time = response.time
            $scope.errorsubcode = response.errorsubcode
            if(installMode=="Fresh"){
                $scope.events = response.fresh;
                allEvents = $scope.fresh;
            }else if(installMode=="Repair"){
                $scope.events = response.repair;
                allEvents = $scope.repair;
            }else if(installMode=="kaizen"){
                $scope.events = response.Wam;
                allEvents = $scope.Wam;
            }else if(installMode=="Auto-Update"){
                $scope.events = response.auto_update;
                allEvents = $scope.auto_update;
            }else if(installMode=="Self-Update"){
                $scope.events = response.self_update;
                allEvents = $scope.self_update;
            }else if(installMode=="LBS-Update"){
                $scope.events = response.lbs_update;
                allEvents = $scope.lbs_update;
            }else if(installMode=="All"){
                $scope.events = response.all_errors;
                allEvents = $scope.all
            }
            
            for(var i=0; i<$scope.events.length; i++)
            {
                var obj = $scope.events[i];
                if(obj["event_type"] == "ACCC_BOOTSTRAP_DL_FATAL_ERROR" || obj["code"] == "ACCC_BOOTSTRAP_DL_FATAL_ERROR")
                {
                    obj["percentage"] = ((obj.workflow_count/allEvents.event_details["Number of Downloads Started"])*100).toFixed(2);
                }
                else if(obj["event_type"] == "ACCC_BOOTSTRAP_INSTALL_FATAL_ERROR" || obj["code"] == "ACCC_BOOTSTRAP_INSTALL_FATAL_ERROR")
                {
                    obj["percentage"] = ((obj.workflow_count/allEvents.event_details["Number of Install Started"])*100).toFixed(2);
                }
            }
            drawChart($scope.events, 'all_errors_piechart', "Overall Error Distribution");
            drawLineChart($scope.events,$scope.events, 'all_errors_piechart', "Overall Error Distribution");
        });
    };
    
    $scope.getBuildData = function($event) {
        $scope.selectedBuild = $($event.target).html();
        //$scope.installModesList = $scope.installModesList;
        //$scope.selectedInstallMode = $scope.installModesList[0];        
        $scope.getOverallDataFromServer($scope.selectedBuild.trim());
    };
    
    $scope.getData = function($event){
        $scope.selectedInstallMode = ($($event.target).html()).trim();        
        $scope.getOverallDataFromServer($scope.selectedBuild.trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = [ "We are using ETS as the database to gather this information.",
                        "This is based on lbsworkfFlowID, i.e. it is based on distinct workflows.", 
                        "We are using the build number to ascertain the range as well as time frame",
                        "Errors: This contains the exact value being logged in ETS for ACCC_BOOTSTRAP_ERRORS",
                        "Error Type: This contains the exact value being logged in ETS for Error_type in ETS"]
    
    $scope.displayEvents = [].concat($scope.events); 
});


//--Misc events.
dashboard.controller('thorMiscEventsController', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.thorBuildsList = thorBuildsForMiscEvents;
    $scope.selectedBuild = $scope.thorBuildsList[0]
    
    $scope.getDataFromServer = function(buildNumber){ 
        $http.get(hostMac+"/api/accmiscevents?buildNumber="+buildNumber, hedrs)
        .success(function (response) {
            $scope.build_number = response.build_number;
            $scope.time = response.time
            $scope.events = response.all_misc_events
        });
    };
    $scope.getDataFromServer($scope.selectedBuild);
    
    $scope.getBuildData = function($event) {
        $scope.selectedBuild = $($event.target).html();
        $scope.getDataFromServer(($scope.selectedBuild).trim());
    };
   
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = [ "We are using ETS as the database to gather this information.",
                        "This is based on lbsworkfFlowID, i.e. it is based on distinct workflows.", 
                        "We are using the build number to ascertain the range as well as time frame"]
    
    $scope.displayEvents = [].concat($scope.events); 
});




dashboard.controller('thorError151Controller', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.thorBuildsList = ['4.0.1.188','4.0.0.185', '3.9.5.353','3.9.1.335','3.9.0.334','3.8.0.310','3.7.5.291','3.7.0.272','3.7.0.272.2','3.7.0.272.1','3.6.0.248','3.5.1.209','3.5.0.206.2','3.5.0.206.1','3.5.0.206','3.4.3.189','3.4.2.187.1','3.4.2.187','3.4.1.181','3.4.0.180','3.4.0.177.2','3.4.0.177.1','3.4.0.177'];
    $scope.selectedBuild = $scope.thorBuildsList[0]
    
    $scope.getDataFromServer = function(buildNumber){
        $http.get(hostMac+"/api/accerrors151?buildNumber="+buildNumber, hedrs)
        .success(function (response) {
            $scope.build_number = response.builds.build_number;
            $scope.time = response.builds.time
            $scope.events = response.builds.event_details;
            $scope.user_errors = response.builds.user_errors;
            $scope.other_errors = response.builds.other_errors;

            drawChart($scope.events, 'all_errors_piechart', "Overall Error Distribution");
            drawChart($scope.user_errors, 'user_errors_piechart', "User Initiated Error Distribution");
            drawChart($scope.other_errors, 'other_errors_piechart', "Non-User Initiated Error Distribution");
        });
    };
    $scope.getDataFromServer($scope.selectedBuild);
    
    $scope.getBuildData = function($event) {
        $scope.selectedBuild = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedBuild).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = ["Build 3.3.0.151.1 represents Thor phased rollout to 20% users",
                          "Build 3.3.0.151.2 represents Thor phased rollout to 80% users", 
                          "We are using ETS as the database to gather this information.",
                          "This is based on lbsworkfFlowID, i.e. it is based on distinct workflows.", 
                          "We are using the build number to ascertain the range, not time frame",
                          "Limiting the number of errors to top 20, based on occurrence.",
                          "Errors: This contains the exact value being logged in ETS for ACCC_BOOTSTRAP_ERRORS",
                          "Error Type: This contains the exact value being logged in ETS for Error_type in ETS"]

    $scope.displayEvents = [].concat($scope.events); 
});

dashboard.controller('thorSuccessCompareController', function($scope, $http, $filter, $location, $anchorScroll) {
    
    $http.get(hostMac+"/api/accsuccess_compare",hedrs)
    .success(function (response) {
        $scope.builds = response.builds;
        $scope.time = response.time;
        $scope.download_success = response.download_success;
        $scope.install_success = response.install_success;
        $scope.total_success = response.total_success;
        $scope.net_of_cancel = response.net_of_cancel;
        $scope.net_success = response.net_success;
        $scope.dl_error_rate = response.dl_error_rate;
        $scope.install_error_rate = response.install_error_rate;
        $scope.error_rate = response.error_rate;
        $scope.backup_error_rate = response.backup_error_rate;
        $scope.quit_error_rate = response.quit_error_rate;
        $scope.event_details = response.event_details;
    });
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = ["We are using ETS as the database to gather this information",
                        "This is based on lbsworkfFlowID, i.e. it is based on distinct workflows", 
                        "We are using the build number to ascertain the range, not time frame",                     
                        "Download Success = No of Download end/Download Started", 
                        "Install Success = No of install end/ Install Started" ,
                        "Thor Success = No of Install End/ Download Started" ,
                        "Thor Cancellation = Number of PIM_STATUS_DOWNLOAD_CANCELED / Download Started", 
                        "Thor Success (Net of Cancel) = No of install end / (Download Started-Cancellation) "]
    
    $scope.displayEvents = $scope.event_details;
});

dashboard.controller('thorSuccessCompare151Controller', function($scope, $http, $filter, $location, $anchorScroll) {
    
    $http.get(hostMac+"/api/accsuccess_compare151",hedrs)
    .success(function (response) {
        $scope.builds = response.builds;
        $scope.time = response.time;
        $scope.download_success = response.download_success;
        $scope.install_success = response.install_success;
        $scope.total_success = response.total_success;
        $scope.net_of_cancel = response.net_of_cancel;
        $scope.net_success = response.net_success;
        $scope.dl_error_rate = response.dl_error_rate;
        $scope.install_error_rate = response.install_error_rate;
        $scope.error_rate = response.error_rate;
        $scope.backup_error_rate = response.backup_error_rate;
        $scope.quit_error_rate = response.quit_error_rate;
        $scope.event_details = response.event_details;
    });
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = ["We are using ETS as the database to gather this information",
                          "This is based on lbsworkfFlowID, i.e. it is based on distinct workflows", 
                          "We are using the build number to ascertain the range, not time frame",                     
                          "Download Success = No of Download end/Download Started", 
                          "Install Success = No of install end/ Install Started" ,
                          "Thor Success = No of Install End/ Download Started" ,
                          "Thor Cancellation = Number of PIM_STATUS_DOWNLOAD_CANCELED / Download Started", 
                          "Thor Success (Net of Cancel) = No of install end / (Download Started-Cancellation) "]
    
    $scope.displayEvents = $scope.event_details;
});

dashboard.controller('panelsVisitController', function($scope, $http, $filter, $location, $anchorScroll) {
    var hedrs = {headers: {
      'Accept': 'application/json'
        }
    };

    $scope.thorReleasesList = ThorPanelVisitReleases;
    $scope.selectedRelease = $scope.thorReleasesList[0] 
    
    $scope.getDataFromServer = function(release){
        $http.get(hostMac+"/api/panels_visit?release="+release,hedrs)
        .success(function (response) {
            //$scope.builds = response.builds
             $scope.panels = response.panels_details;
             $scope.time = response.time
        });
    };
    
    $scope.getDataFromServer($scope.selectedRelease);
     $scope.getReleaseData = function($event) {
        $scope.selectedRelease = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedRelease).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = ["We are using ETS as the database to gather this information.",
                        "This is based  on ACCC_Machine_id, i.e. it is based on distinct Machine ID’s.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh. ",
                        "The panel Visit is ascertained by values being logged for ACCC_%_VISIT events"]
    
    $scope.displayEvents = [].concat($scope.panels); 
});

dashboard.controller('hdSuccessController', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.thorReleasesList = thorReleases;
    $scope.selectedRelease = $scope.thorReleasesList[0]
       	
	$scope.getDataFromServer = function(release){
        
        $http.get(hostMac+"/api/hdsuccess?release="+release,hedrs)
        .success(function (response) {   
            $scope.build_number = response.builds.build_number;
            $scope.time = response.builds.time
            $scope.download_success = response.builds.download_success;
            $scope.install_success = response.builds.install_success;
            $scope.hd_success = response.builds.hd_success;
            $scope.hd_cancel = response.builds.hd_cancel;
            $scope.net_success = response.builds.net_success;
            $scope.error_rate = response.builds.error_rate;
            $scope.events = response.builds.event_details;        
        });
	};
    $scope.getDataFromServer($scope.selectedRelease);
    
    $scope.getReleaseData = function($event) {
        $scope.selectedRelease = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedRelease).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = ["We are using ETS as the database to gather this information.",
                        "This is based on Session_ID, i.e. it is based on distinct sessions.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh. ",
                        "Download Success = No of Download end/Download Started",
                        "Install Success = No of install end/ Download end",
                        "HyperDrive Success = No of Install End/ Download Started",
                        "HyperDrive Cancellation = Number of DOWNLOAD_CANCELED / Download Started. ( Reason we are just using Download cancelled for HD is because download and install   happen in together. Going forward this even will be changed to just HD_Cancel.",
                        "HyperDrive Success( Net of Cancel) = No of install end / (Download Started- Download Cancellation)"]

    $scope.displayEvents = [].concat($scope.events);
});


dashboard.controller('hdErrorController', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.thorReleasesList = thorReleases;
    $scope.selectedRelease = $scope.thorReleasesList[0]
    
    $scope.getDataFromServer = function(release){
        $http.get(hostMac+"/api/hderrors?release="+release,hedrs)
        .success(function (response) {
            $scope.build_number = response.builds.build_number;
            $scope.time = response.builds.time
            $scope.events = response.builds.event_details;        
        });
    };
    $scope.getDataFromServer($scope.selectedRelease);
    
    $scope.getReleaseData = function($event) {
        $scope.selectedRelease = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedRelease).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = [ "We are using ETS as the database to gather this information.",
                        "This is based on Session_ID, i.e. it is based on distinct sessions.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh. ",
                        "Limiting the number of errors to top 20, based on occurrence.",
                        "Errors: This contains the exact value being logged in ETS for ACCC_ERRORS for ERROR_CODE",
                        "Error Type: This contains the exact value being logged in ETS for Error_type in ETS"]

    $scope.displayEvents = [].concat($scope.events);
});

dashboard.controller('hd2ErrorProductWiseController', function($scope, $http, $filter, $location, $anchorScroll) {
    
    $scope.getDataFromServer = function(release){
        $http.get(hostMac+"/api/hd2errorsproducts?release="+release,hedrs)
        .success(function (response) {
            $scope.build_number = response.builds.build_number;
            $scope.time = response.builds.time;
            $scope.thorProductList = response.builds.products;
            //$scope.selectedProduct = $scope.thorProductList[0]
            $scope.events = response.builds.event_details;        
        });
    };
    $scope.getDataFromServer($scope.selectedProduct);
    
    $scope.getReleaseData = function($event) {
        $scope.selectedProduct = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedProduct).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.shouldProductToBeShow = function(name)
    {
        if(name == 'COSY')
        {        
            return false;
        }
        return true;
    };
    
    $scope.assumptions = [ "We are using ETS as the database to gather this information.",
                        "This is based on Session_ID, i.e. it is based on distinct sessions.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh. ",
                        "Limiting the number of errors to top 20, based on occurrence.",
                        "Errors: This contains the exact value being logged in ETS for ACCC_ERRORS for ERROR_CODE",
                        "Error Type: This contains the exact value being logged in ETS for Error_type in ETS"]

    $scope.displayEvents = [].concat($scope.events);

});

/*
dashboard.controller('hd2ErrorController', function($scope, $http, $filter, $location, $anchorScroll) {
    var thorReleaseshd2 = ["3.9.0.334","3.8.0.310","3.7.5.291","3.7.0.272", "3.6.0.248", "3.5.1.209","3.4.1.181"];
    $scope.thorReleasesList = thorReleaseshd2;
    $scope.selectedRelease = $scope.thorReleasesList[0]
    
    $scope.getDataFromServer = function(release){
        $http.get(hostMac+"/api/hd2errors?release="+release,hedrs)
        .success(function (response) {
            $scope.build_number = response.builds.build_number;
            $scope.time = response.builds.time
            $scope.events = response.builds.event_details;        
        });
    };
    $scope.getDataFromServer($scope.selectedRelease);
    
    $scope.getReleaseData = function($event) {
        $scope.selectedRelease = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedRelease).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = [ "We are using ETS as the database to gather this information.",
                        "This is based on Session_ID, i.e. it is based on distinct sessions.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh. ",
                        "Limiting the number of errors to top 20, based on occurrence.",
                        "Errors: This contains the exact value being logged in ETS for ACCC_ERRORS for ERROR_CODE",
                        "Error Type: This contains the exact value being logged in ETS for Error_type in ETS"]

    $scope.displayEvents = [].concat($scope.events);
});
*/

dashboard.controller('hd2ErrorController', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.thorReleasesList = hdThorReleases;
    $scope.selectedRelease = $scope.thorReleasesList[0]
	
	var thorProductHD2 = ["ALL","ILST","PHSP", "AICY", "AME", "PPRO", "AEFT", "KBRG", "FLPR", "MUSE", "AUDT", "PRLD", "SPRK", "IDSN","LTRM","LRCC","ESHR","DRWV","CHAR","RUSH"];
    $scope.thorProductsList = thorProductHD2;
    $scope.selectedProduct = $scope.thorProductsList[0]

    $scope.getDataFromServer = function(release, product){
        $http.get(hostMac+"/api/hd2errors?release="+release+"&product="+product,hedrs)
        .success(function (response) {
            $scope.build_number = response.builds.build_number;
            $scope.time = response.builds.time
            $scope.events = response.builds.event_details;        
        });
    };
    $scope.getDataFromServer($scope.selectedRelease, $scope.selectedProduct);
    
    $scope.getReleaseData = function($event) {
        $scope.selectedRelease = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedRelease).trim(), ($scope.selectedProduct).trim());
    };

    $scope.getProductData = function($event) {
        $scope.selectedProduct = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedRelease).trim(), ($scope.selectedProduct).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = [ "We are using ETS as the database to gather this information.",
                        "This is based on Session_ID, i.e. it is based on distinct sessions.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh. ",
                        "Limiting the number of errors to top 20, based on occurrence.",
                        "Errors: This contains the exact value being logged in ETS for ACCC_ERRORS for ERROR_CODE",
                        "Error Type: This contains the exact value being logged in ETS for Error_type in ETS"]

    $scope.displayEvents = [].concat($scope.events);
});

dashboard.controller('hd2ResourceErrorController', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.thorReleasesList = hdResourceErrorReleases;
    $scope.selectedRelease = $scope.thorReleasesList[0]
	
	var thorProductHD2 = ["ALL","ILST","PHSP", "AICY", "AME", "PPRO", "AEFT", "KBRG", "FLPR", "MUSE", "AUDT", "PRLD", "SPRK", "IDSN","LTRM","LRCC","ESHR","DRWV","CHAR","RUSH"];
    $scope.thorProductsList = thorProductHD2;
    $scope.selectedProduct = $scope.thorProductsList[0]

    $scope.getDataFromServer = function(release, product){
        $http.get(hostMac+"/api/hd2ResourceErrors?release="+release+"&product="+product,hedrs)
        .success(function (response) {
            $scope.build_number = response.builds.build_number;
            $scope.time = response.builds.time
            $scope.events = response.builds.event_details;        
        });
    };
    $scope.getDataFromServer($scope.selectedRelease, $scope.selectedProduct);
    
    $scope.getReleaseData = function($event) {
        $scope.selectedRelease = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedRelease).trim(), ($scope.selectedProduct).trim());
    };

    $scope.getProductData = function($event) {
        $scope.selectedProduct = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedRelease).trim(), ($scope.selectedProduct).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = [ "We are using ETS as the database to gather this information.",
                        "This is based on Session_ID, i.e. it is based on distinct sessions.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh. ",
                        "Limiting the number of errors to top 20, based on occurrence.",
                        "Errors: This contains the exact value being logged in ETS for ACCC_RESOURCE_ERRORS for ERROR_CODE",
                        "Error Type: This contains the exact value being logged in ETS for Error_type in ETS"]

    $scope.displayEvents = [].concat($scope.events);
});

dashboard.controller('hd2UpdatesErrorController', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.thorReleasesList = thorReleasesForHDUpdates;
    $scope.selectedRelease = $scope.thorReleasesList[0]
	
	var thorProductHD2 = ["ALL","ILST","PHSP", "AICY", "AME", "PPRO", "AEFT", "KBRG", "FLPR", "MUSE", "AUDT", "PRLD", "SPRK", "IDSN","LTRM","LRCC","ESHR","DRWV","CHAR","RUSH"];
    $scope.thorProductsList = thorProductHD2;
    $scope.selectedProduct = $scope.thorProductsList[0]

    $scope.getDataFromServer = function(release, product){
        $http.get(hostMac+"/api/hd2updateserrors?release="+release+"&product="+product,hedrs)
        .success(function (response) {
            $scope.build_number = response.builds.build_number;
            $scope.time = response.builds.time
            $scope.events = response.builds.event_details;        
        });
    };
    $scope.getDataFromServer($scope.selectedRelease, $scope.selectedProduct);
    
    $scope.getReleaseData = function($event) {
        $scope.selectedRelease = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedRelease).trim(), ($scope.selectedProduct).trim());
    };

    $scope.getProductData = function($event) {
        $scope.selectedProduct = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedRelease).trim(), ($scope.selectedProduct).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = [ "We are using ETS as the database to gather this information.",
                        "This is based on Session_ID, i.e. it is based on distinct sessions.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh. ",
                        "Limiting the number of errors to top 20, based on occurrence.",
                        "Errors: This contains the exact value being logged in ETS for ACCC_ERRORS for ERROR_CODE",
                        "Error Type: This contains the exact value being logged in ETS for Error_type in ETS"]

    $scope.displayEvents = [].concat($scope.events);
});


dashboard.controller('hdSuccessCompareController', function($scope, $http, $filter, $location, $anchorScroll) {
    
    $http.get(hostMac+"/api/hdsuccess_compare",hedrs)
    .success(function (response) {
        
        $scope.builds = response.builds;
        $scope.time = response.time;
        $scope.download_success = response.download_success;
        $scope.install_success = response.install_success;
        $scope.hd_success = response.hd_success;
        $scope.hd_cancel = response.hd_cancel;
        $scope.net_success = response.net_success;
        $scope.error_rate = response.error_rate;
        $scope.event_details = response.event_details;
    });
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = ["We are using ETS as the database to gather this information.", 
                        "This is based on Session_ID, i.e. it is based on distinct sessions.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh. In addition we also are the Thor build version to get build version on the machine.",
                        "Download Success = No of Download end/Download Started",
                        "Install Success = No of install end/ Download end",
                        "HyperDrive Success = No of Install End/ Download Started",
                        "HyperDrive Cancellation = Number of DOWNLOAD_CANCELED / Download Started. ( Reason we are just using Download cancelled for HD is because download and install happen in together. Going forward this even will be changed to just HD_Cancel.",
                        "HyperDrive Success( Net of Cancel) = No of install end / (Download Started- Download Cancellation)"]

    $scope.displayEvents = $scope.event_details;
});

dashboard.controller('hdSuccessDetailsController', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.thorReleasesList = thorReleases;
    $scope.selectedRelease = $scope.thorReleasesList[0]
    
    $scope.getDataFromServer = function(release){
        $http.get(hostMac+"/api/hdapps_detailed_info?release="+release,hedrs)
        .success(function (response) {
            $scope.time = response.time
            $scope.details = response.details
        });
    };
    $scope.getDataFromServer($scope.selectedRelease);
    
    $scope.getReleaseData = function($event) {
        $scope.selectedRelease = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedRelease).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions =["We are using ETS as the database to gather this information.",
                        "This is based on Session_ID, i.e. it is based on distinct sessions.",
                        "Size mentioned is based the metadata of GM builds posted via FFC. This is hardcoded data as this would not change. ",
                        "For Products for which CC 2014 is being shown as “zero”, means no new version was posted for CC 2015 release, hence the last available version size is being shown under CC 2015 tab.",
                        "Download Success and Download Cancel refer to CC 2015 Version and not older.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh for Download Success and Download Cancel. ",
                        "Download Success: No of Download end/Download Started",
                        "CC Products Cancellation: (Number of DOWNLOAD_CANCELED + Number of Install Cancelled) / Download Started"]

    $scope.displayDetails = [].concat($scope.details);
});

dashboard.controller('forumsController', function($scope, $http, $filter, $location, $anchorScroll) {
        
    $http.get(hostMac+ "/api/forums",hedrs)
    .success(function (response) {
        $scope.time = response.time;
        $scope.events = response.event_details;
        $scope.count = response.count;
    });
    $scope.displayCount = [].concat($scope.count);
    $scope.displayEvents = [].concat($scope.events);

});
dashboard.controller('max_18Controller', function($scope, $http, $filter, $location, $anchorScroll) {

    //$scope.selectedBuild = $scope.autoUpdateBuildList[0]; //just for now
        
    $scope.getDataFromServer = function(buildNumber){
        $http.get(hostMac+"/api/max_18?buildNumber=" + buildNumber, hedrs)
        .success(function (response) {
            $scope.time = response.time;
            $scope.installStarted=response.installStarted;
            $scope.usersCancelled=response.usersCancelled;
            $scope.usersError=response.usersError;
            $scope.successfulInstall=response.successfulInstall;
            
            $scope.usersCancelledRate=Number(($scope.usersCancelled/$scope.installStarted)*100).toFixed(2);
            $scope.usersErrorRate=Number(($scope.usersError/$scope.installStarted)*100).toFixed(2);
            $scope.successfulInstallRate=Number(($scope.successfulInstall/$scope.installStarted)*100).toFixed(2);
            
            $scope.productWiseToSend=response.productWiseToSend;
        });
    };
    
     $scope.getDataFromServer("4.7.0.400");
    
    

});

dashboard.controller('crashReportController', function($scope, $http, $filter, $location, $anchorScroll) {
        
    $http.get(hostMac+ "/api/crash_report",hedrs)
    .success(function (response) {
        $scope.time = response.time
        console.log($scope.time);
        $scope.events = response.event_details;
        console.log($scope.events);
    });
    
    $scope.displayEvents = [].concat($scope.events);
});

dashboard.controller('confPercentController', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.thorReleasesList = thorReleases;
    $scope.selectedRelease = $scope.thorReleasesList[0]
    
    $scope.getDataFromServer = function(release){
        $http.get(hostMac+ "/api/conf_percent?release="+release,hedrs)
        .success(function (response) {
            $scope.build_number = response.builds.build_number;
            $scope.time = response.builds.time
            $scope.events = response.builds.event_details;
        });
    };
    $scope.getDataFromServer($scope.selectedRelease);
    
    $scope.getReleaseData = function($event) {
        $scope.selectedRelease = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedRelease).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = [ "We are using ETS as the database to gather this information.",
                        "This is based on user_guid, i.e. it is based on distinct users.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh. ",
                        "Install Starts is equal to number of users for whom the ACCC_INSTALL_START event came.",
                        "Conflicting count is based on the occurrence of ACCC_APPS_PANEL_CONFLICTINGPROCESS_DIALOG.",
                        "Conflicting Percentage = Conflicting Count/Install Start",
                        "We have just categorized based on Product and not segregated for versions. For example, for Photoshop the count reflects for all Product_ID= Photoshop, irrespective of version."]

    $scope.displayEvents = [].concat($scope.events);
});

dashboard.controller('confPercentV2Controller', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.thorReleasesList = thorReleases;
    $scope.selectedRelease = $scope.thorReleasesList[0]
    
    $scope.getDataFromServer = function(release){
        $http.get(hostMac+ "/api/conf_percent_v2?release="+release,hedrs)
        .success(function (response) {
            $scope.build_number = response.build_number;
            $scope.time = response.time
            $scope.events = response.event_details;
        });
    };
    $scope.getDataFromServer($scope.selectedRelease);
    
    $scope.getReleaseData = function($event) {
        $scope.selectedRelease = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedRelease).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = [ "We are using ETS as the database to gather this information.",
                        "This is based on user_guid, i.e. it is based on distinct users.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh. ",
                        "Install Starts is equal to number of users for whom the ACCC_INSTALL_START event came.",
                        "Conflicting count is based on the occurrence of ACCC_APPS_PANEL_CONFLICTINGPROCESS_DIALOG.",
                        "Conflicting Percentage = Conflicting Count/Install Start",
                        "We have just categorized based on Product and not segregated for versions. For example, for Photoshop the count reflects for all Product_ID= Photoshop, irrespective of version."]

    $scope.displayEvents = [].concat($scope.events);
});

dashboard.controller('confProcessController', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.thorReleasesList = thorReleases;
    $scope.selectedRelease = $scope.thorReleasesList[0]
    
    $scope.getDataFromServer = function(release){
        $http.get(hostMac+ "/api/conf_process_V2?release="+release,hedrs)
        .success(function (response) {
            $scope.build_number = response.build_number;
            $scope.time = response.time
            $scope.dl_events = response.dl_event_details;
            $scope.install_events = response.install_event_details;
        });
    };
    $scope.getDataFromServer($scope.selectedRelease);
    
    $scope.getReleaseData = function($event) {
        $scope.selectedRelease = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedRelease).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions =[ "We are using ETS as the database to gather this information.",
                        "This is based on user_guid, i.e. it is based on distinct users.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh. ", 
                        "We have just categorized based on Product and not segregated for versions. For example, for Photoshop the count reflects for all Product_ID= Photoshop, irrespective of version.", 
                        "Process name is what is displayed in CONFLICTINGPROCESS_DIALOG, and may or may not tie up with exact process name in the activity monitor.",
                        "Incase of multiple conflicts being reported, we have segregated and shown the entries separately. For example for conflict with Photoshop and Illustrator, it is divided into two entries.",
                        "Count is the unique occurrence of that process for that product family.",
                        "Count merger for single and multiple conflicts for same process name has not been done. For example if Photoshop conflict is occurring just as Photoshop and in another case as Photoshop and Illustrator, then they would be shown as separate entries."]

    $scope.dlDisplayEvents = [].concat($scope.dl_events);
    $scope.installDisplayEvents = [].concat($scope.install_events);
});

dashboard.controller('ccappsSuccessController', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.thorReleasesList = thorReleases;
    $scope.selectedRelease = $scope.thorReleasesList[0]
    
    $scope.getDataFromServer = function(release){
        $http.get(hostMac+"/api/ccapps_success?release="+release, hedrs)
        .success(function (response) {
            console.log(response);
            $scope.build_number = response.builds.build_number;
            $scope.time = response.builds.time
            $scope.download_success = response.builds.download_success;
            $scope.install_success = response.builds.install_success;
            $scope.ccapps_success = response.builds.ccapps_success;
            $scope.ccapps_cancel = response.builds.ccapps_cancel;
            $scope.dl_cancel = response.builds.dl_cancel;
            $scope.install_cancel = response.builds.install_cancel;
            $scope.net_success = response.builds.net_success;
            $scope.error_rate = response.builds.error_rate;
            $scope.events = response.builds.event_details;
        });
    };
    $scope.getDataFromServer($scope.selectedRelease);
    
    $scope.getReleaseData = function($event) {
        $scope.selectedRelease = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedRelease).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = [ "We are using ETS as the database to gather this information.",
                        "This is based on Session_ID, i.e. it is based on distinct sessions.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh. ",
                        "This includes all CC products. ",
                        "Download Success = No of Download end/Download Started",
                        "Install Success = No of install end/ No Of Install Start",
                        "CC Products Success = No of Install End/ Download Started",
                        "CC Products Cancellation = (Number of DOWNLOAD_CANCELED + Number of Install Cancelled) / Download Started. ",
                        "CC Products Success( Net of Cancel) = No of install end / (Download Started- Cancellation(Number of DOWNLOAD_CANCELED+ Number of Install Cancelled))"]

    $scope.displayEvents = [].concat($scope.events);
});

dashboard.controller('ccappsErrorController', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.thorReleasesList = thorReleases;
    $scope.selectedRelease = "";
    $scope.errorCodesList = "";
    $scope.selectedErrorCode = "";
    
    $scope.getErrorsData = function(release){
        $http.get(hostMac+"/api/ccapps_errors?release="+release,hedrs)
        .success(function (response) {
            $scope.build_number = response.builds.build_number;
            $scope.time = response.builds.time
            $scope.events = response.builds.event_details;        
        });    
    };
    
    $scope.getSuberrorsData = function(release, errorCode){        
        $http.get(hostMac+"/api/ccapps_suberrors?release="+release,hedrs)
        .success(function (response) {
            $scope.build_number = response.builds.build_number;
            $scope.time = response.builds.time
            if(errorCode=='6')
                $scope.events = response.builds.error_code_6;
            else if(errorCode=='7')
                $scope.events = response.builds.error_code_7;
        });
    };
    //$scope.getErrorsData()
    
    $scope.getErrorsList = function($event){
        $scope.selectedRelease = ($($event.target).html()).trim();
        $scope.errorCodesList = ['All', '6', '7'];
        $scope.selectedErrorCode = "";
    };
    
    $scope.getData = function($event){
        $scope.selectedErrorCode = ($($event.target).html()).trim();
        if($scope.selectedErrorCode=='All')
            $scope.getErrorsData($scope.selectedRelease)
        else
            $scope.getSuberrorsData($scope.selectedRelease, $scope.selectedErrorCode);
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = [ "We are using ETS as the database to gather this information.",
                        "This is based on Session_ID, i.e. it is based on distinct sessions.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh. ",
                        "Limiting the number of errors to top 20, based on occurrence.",
                        "Errors: This contains the exact value being logged in ETS for ACCC_ERRORS for ERROR_CODE",
                        "Error Type: This contains the exact value being logged in ETS for Error_type in ETS"]
    
    $scope.displayEvents = [].concat($scope.events);
    
});

dashboard.controller('ccappsDetailsController', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.thorReleasesList = thorReleases;
    $scope.selectedRelease = $scope.thorReleasesList[0]
    
    $scope.getDataFromServer = function(release){
        $http.get(hostMac+"/api/ccapps_detailed_info?release="+release,hedrs)
        .success(function (response) {
            $scope.time = response.time
            $scope.details = response.details
        });
    };
    $scope.getDataFromServer($scope.selectedRelease);
    
    $scope.getReleaseData = function($event) {
        $scope.selectedRelease = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedRelease).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions =["We are using ETS as the database to gather this information.",
                        "This is based on Session_ID, i.e. it is based on distinct sessions.",
                        "Size mentioned is based the metadata of GM builds posted via FFC. This is hardcoded data as this would not change. ",
                        "For Products for which CC 2014 is being shown as “zero”, means no new version was posted for CC 2015 release, hence the last available version size is being shown under CC 2015 tab.",
                        "Download Success and Download Cancel refer to CC 2015 Version and not older.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh for Download Success and Download Cancel. ",
                        "Download Success: No of Download end/Download Started",
                        "CC Products Cancellation: (Number of DOWNLOAD_CANCELED + Number of Install Cancelled) / Download Started"]

    $scope.displayDetails = [].concat($scope.details);
});

dashboard.controller('productSummaryController', function($scope, $http, $filter, $location, $anchorScroll) {
    $http.get(hostMac+"/api/product_summary",hedrs)
    .success(function (response) {
        
        $scope.build_number = response.builds.build_number;
        $scope.time = response.builds.time
        $scope.events = response.builds.event_details;  
        $scope.product = response.builds.product;
        $scope.download_success = response.builds.download_success;
        $scope.install_success = response.builds.install_success;
        $scope.total_success = response.builds.total_success;
        $scope.net_cancel = response.builds.net_cancel;
        $scope.net_success = response.builds.net_success;
        $scope.error_rate = response.builds.error_rate;
        $scope.version = response.builds.version;
    });
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions =[ "We are using ETS as the database to gather this information.",
                        "This is based on Session_ID, i.e. it is based on distinct sessions.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh. ",
                        "Download Success = No of Download end/Download Started",
                        "Install Success = No of install end/ No Of Install Start",
                        "Photoshop Success = No of Install End/ Download Started",
                        "Photoshop  Cancellation = (Number of DOWNLOAD_CANCELED + Number of Install Cancelled) / Download Started. ",
                        "Photoshop  Success( Net of Cancel) = No of install end / (Download Started- Cancellation(Number of DOWNLOAD_CANCELED+ Number of Install Cancelled))"]
    
    $scope.displayEvents = [].concat($scope.events);
});

dashboard.controller('productErrorsController', function($scope, $http, $filter, $location, $anchorScroll) {
    var hedrs = {headers: {
      'Accept': 'application/json'
        }
    };
    $http.get(hostMac+"/api/product_errors",hedrs)
    .success(function (response) {
        $scope.time = response.builds.time
        $scope.events = response.builds.event_details;  
    });
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = [ "We are using ETS as the database to gather this information.",
                        "This is based on Session_ID, i.e. it is based on distinct sessions.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh. ",
                        "Limiting the number of errors to top 20, based on occurrence.",
                        "Errors: This contains the exact value being logged in ETS for ACCC_ERRORS for ERROR_CODE",
                        "Error Type: This contains the exact value being logged in ETS for Error_type in ETS"]
    
    $scope.displayEvents = [].concat($scope.events);
});

dashboard.controller('productsSizeController', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.platformsList = platforms;
    $scope.selectedPlatform = $scope.platformsList[0];
    
    $http.get(hostMac+"/api/ccapps_size",hedrs)
    .success(function (response) {
        $scope.time = response.time
        $scope.win = response.win
        $scope.mac = response.mac
        $scope.size = $scope.win;
    });
    
    $scope.getData = function($event) {
        $scope.selectedPlatform = $($event.target).html()
        if(($scope.selectedPlatform).trim() == "Win"){
            $scope.size = $scope.win;
        }else{
            $scope.size = $scope.mac;
        }
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions =["We are using ETS as the database to gather this information.",
                        "This is based on Session_ID, i.e. it is based on distinct sessions.",
                        "Size mentioned is based the metadata of GM builds posted via FFC. This is hardcoded data as this would not change. ",
                        "For Products for which CC 2014 is being shown as “zero”, means no new version was posted for CC 2015 release, hence the last available version size is being shown under CC 2015 tab.",
                        "Download Success and Download Cancel refer to CC 2015 Version and not older.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh for Download Success and Download Cancel. ",
                        "Download Success: No of Download end/Download Started",
                        "CC Products Cancellation: (Number of DOWNLOAD_CANCELED + Number of Install Cancelled) / Download Started"]

    $scope.displayWin = [].concat($scope.win);
    $scope.displayMac = [].concat($scope.mac);
    $scope.displaySize = [].concat($scope.size);
});

dashboard.controller('ribsHdAIController', function($scope, $http, $filter, $location, $anchorScroll) {
    var hedrs = {headers: {
      'Accept': 'application/json'
        }
    };
    $http.get(hostMac+"/api/ribs_hd_ai",hedrs)
    .success(function (response) {
        //$scope.builds = response.builds
         $scope.techType = response.techType;
         $scope.download_success = response.download_success;
         $scope.install_success = response.install_success;
         $scope.total_success = response.total_success;
         $scope.net_cancel = response.net_cancel;
         $scope.net_success = response.net_success;
         $scope.events = response.event_details;
         $scope.time = response.time
    });
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = ["We are using ETS as the database to gather this information.",
                        "This is based on Session_ID, i.e. it is based on distinct sessions.",
                        "We are using the ACCC_HYPERDRIVE_BUILD_PVALUE, to ascertain RIBS or HD as the build type. This is only being done for ILLUSTRATOR CC 2015.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh. ",
                        "Download Success = No of Download end/Download Started",
                        "Install Success = No of install end/ Download end",
                        "HyperDrive Success = No of Install End/ Download Started",
                        "HyperDrive Cancellation = Number of DOWNLOAD_CANCELED / Download Started. ( Reason we are just using Download cancelled for HD is because download and install happen in together. Going forward this even will be changed to just HD_Cancel.",
                        "HyperDrive Success( Net of Cancel) = No of install end / (Download Started-Download Cancellation)"]

    $scope.displayEvents = [].concat($scope.events); 
});

dashboard.controller('productsMonthlyDetailController', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.updateChart = function(events){
        downloadSuccess = []
        installSuccess = []
        totalSuccess = []
        cancellations = []
        netSuccess = []
        for (key in $scope.events){
            downloadSuccess.push(events[key]["mn_download_success"]);
            installSuccess.push(events[key]["mn_install_success"]);
            totalSuccess.push(events[key]["mn_total_success"]);
            cancellations.push(events[key]["mn_net_cancel"]);
            netSuccess.push(events[key]["mn_net_success"]);
        }
        return ([ downloadSuccess, installSuccess, totalSuccess, cancellations, netSuccess]);
    }
    
    $http.get(hostMac+"/api/products_monthly_detail",hedrs)
    .success(function (response) {
        console.log(response);
        $scope.months = response.months;
        $scope.productsList = response.products;
        $scope.selectedProduct = $scope.productsList[0];
        $scope.selectedVersion = response[$scope.selectedProduct]["versions"][0];
        $scope.events = response[$scope.selectedProduct][$scope.selectedVersion]
            
        $scope.getVersions = function($event){
            $scope.selectedProduct = ($($event.target).html()).trim();
            $scope.versionsList = response[$scope.selectedProduct]["versions"];
        };
        
        $scope.getData = function($event){
            $scope.selectedVersion = ($($event.target).html()).trim();
            $scope.events = response[$scope.selectedProduct][$scope.selectedVersion];
            $scope.data = $scope.updateChart($scope.events);
        };
        
        $scope.labels = $scope.months;
        $scope.series = ['Download Success', 'Install Success', "Total Success", "Cancellations", "Total Success (Net of Cancel)"];
        $scope.data = $scope.updateChart($scope.events);
        console.log($scope.updateChart);
        $scope.onClick = function (points, evt) {
            console.log(points, evt);
        };
    });
});



dashboard.controller('funnelController', function($scope, $http, $filter, $timeout, $q, $location, $anchorScroll) {
     $scope.thorBuildsList = thorBuilds;
    $scope.selectedBuild = $scope.thorBuildsList[0];
    
      $scope.getBuildData = function($event){
        $scope.selectedBuild = ($($event.target).html()).trim();
          console.log("In click event",$scope.selectedBuild);
        $scope.getDataFromServer(($scope.selectedBuild).trim());
    };
        
     
   
   $scope.myDataSourcePHSP = {
    "chart": {
        "caption": "Funnel Summary",
        "bgcolor": "FFFFFF",
        "numbersuffix": "%",
        "subcaption": "PHSP",
        "decimals": "1",
        "basefontsize": "11",
        "issliced": "0",
        "usesameslantangle": "1",
        "ishollow": "0",
        "labeldistance": "5",
        "showborder": "0"
    },
    "data": 0
   }
   
   
   $scope.myDataSourceILST = {
    "chart": {
        "caption": "Funnel Summary",
        "bgcolor": "FFFFFF",
        "numbersuffix": "%",
        "subcaption": "ILST",
        "decimals": "1",
        "basefontsize": "11",
        "issliced": "0",
        "usesameslantangle": "1",
        "ishollow": "0",
        "labeldistance": "5",
        "showborder": "0"
    },
    "data": 0
   }
    
   $scope.myDataSourceIDSN = {
    "chart": {
        "caption": "Funnel Summary",
        "bgcolor": "FFFFFF",
        "numbersuffix": "%",
        "subcaption": "IDSN",
        "decimals": "1",
        "basefontsize": "11",
        "issliced": "0",
        "usesameslantangle": "1",
        "ishollow": "0",
        "labeldistance": "5",
        "showborder": "0"
    },
    "data": 0
   }
   
   $scope.myDataSourceKBRG = {
    "chart": {
        "caption": "Funnel Summary",
        "bgcolor": "FFFFFF",
        "numbersuffix": "%",
        "subcaption": "KBRG",
        "decimals": "1",
        "basefontsize": "11",
        "issliced": "0",
        "usesameslantangle": "1",
        "ishollow": "0",
        "labeldistance": "5",
        "showborder": "0"
    },
    "data": 0
   }
   
 
   $scope.myDataSourceLTRM = {
    "chart": {
        "caption": "Funnel Summary",
        "bgcolor": "FFFFFF",
        "numbersuffix": "%",
        "subcaption": "ILST",
        "decimals": "1",
        "basefontsize": "11",
        "issliced": "0",
        "usesameslantangle": "1",
        "ishollow": "0",
        "labeldistance": "5",
        "showborder": "0"
    },
    "data": 0
   }
   
   $scope.myDataSourceAPRO = {
    "chart": {
        "caption": "Funnel Summary",
        "bgcolor": "FFFFFF",
        "numbersuffix": "%",
        "subcaption": "ILST",
        "decimals": "1",
        "basefontsize": "11",
        "issliced": "0",
        "usesameslantangle": "1",
        "ishollow": "0",
        "labeldistance": "5",
        "showborder": "0"
    },
    "data": 0
   }
   
     $scope.myDataSourcePPRO = {
    "chart": {
        "caption": "Funnel Summary",
        "bgcolor": "FFFFFF",
        "numbersuffix": "%",
        "subcaption": "PPRO",
        "decimals": "1",
        "basefontsize": "11",
        "issliced": "0",
        "usesameslantangle": "1",
        "ishollow": "0",
        "labeldistance": "5",
        "showborder": "0"
    },
    "data": 0
   }
   
     
   $scope.myDataSourceAEFT = {
    "chart": {
        "caption": "Funnel Summary",
        "bgcolor": "FFFFFF",
        "numbersuffix": "%",
        "subcaption": "AEFT",
        "decimals": "1",
        "basefontsize": "11",
        "issliced": "0",
        "usesameslantangle": "1",
        "ishollow": "0",
        "labeldistance": "5",
        "showborder": "0"
    },
    "data": 0
   }
   
   
    $scope.getDataFromServer= function(buildNumber){
    console.log(buildNumber)
    $http.get(hostMac+"/api/funnelData?buildNumber="+buildNumber, hedrs)
    .success(function (response) {
        $scope.funnelData = response.phsp
        $scope.myDataSourcePHSP["data"] = response.phsp
        $scope.myDataSourceILST["data"] = response.ilst
        $scope.myDataSourceIDSN["data"] = response.idsn
        $scope.myDataSourceKBRG["data"] = response.kbrg
        $scope.myDataSourceLTRM["data"] = response.ltrm
        $scope.myDataSourceAPRO["data"] = response.apro
        $scope.myDataSourcePPRO["data"] = response.ppro
        $scope.myDataSourceAEFT["data"] = response.aeft
console.log( $scope.myDataSource1);
     });
    };
    
    $scope.getDataFromServer($scope.selectedBuild);
    
});

dashboard.controller('kaizenSuccessController', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.kaizenReleasesList = kaizenReleases;
    $scope.selectedRelease = $scope.kaizenReleasesList[0]

    $scope.kaizenProductsList = kaizenProducts;
    $scope.selectedProduct = $scope.kaizenProductsList[0]
    
	$scope.getDataFromServer = function(release, product){
        $http.get(hostMac+"/api/kaizen_success?release="+release +"&product="+product, hedrs)
        .success(function (response) {
            console.log(response);
            $scope.build_number = response.builds.build_number;
            $scope.time = response.builds.time;
			$scope.stats = response.builds.stats;
			$scope.Failuresstats = response.builds.WorkflowFailurestats;
        });
    };
	
    $scope.getDataFromServer($scope.selectedRelease, $scope.selectedProduct);
    
    $scope.getReleaseData = function($event) {
		$scope.selectedRelease = $($event.target).html();
		$scope.getDataFromServer(($scope.selectedRelease).trim(), ($scope.selectedProduct).trim());
    };
	
	$scope.getProductData = function($event) {
		$scope.selectedProduct = $($event.target).html();
		$scope.getDataFromServer(($scope.selectedRelease).trim() , ($scope.selectedProduct).trim());
	};
	
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = [ "We are using ETS as the database to gather this information.",
                        "This is based on lbsWorkflowID, i.e. it is based on distinct sessions.",
                        "We are using timeframe as CC launch date (2016-02-09) till last refresh. ",
                        "This includes all CC products. ",
                        "Download Success = No of Download end/Download Started",
                        "Install Success = No of install end/ No Of Install Start",
                        "CC Products Success = No of Install End/ Download Started",
                        "CC Products Cancellation = (Number of DOWNLOAD_CANCELED + Number of Install Cancelled) / Download Started. ",
                        "CC Products Success( Net of Cancel) = No of install end / (Download Started- Cancellation(Number of DOWNLOAD_CANCELED+ Number of Install Cancelled))"]

    $scope.displayThorEvents = [].concat($scope.eventsThor);
    $scope.displayProductEvents = [].concat($scope.eventsProduct);
});


dashboard.controller('kaizenErrorController', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.kaizenReleasesList = kaizenReleases;
    $scope.selectedRelease = $scope.kaizenReleasesList[0];
	
	$scope.kaizenProductsList = kaizenProducts;
    $scope.selectedProduct = $scope.kaizenProductsList[0]
	
    $scope.errorCodesList = "";
    $scope.selectedErrorCode = "";
    $scope.kaizenInstallationSteps = thorInstallationSteps;
    
    $scope.getErrorsData = function(release, product){
        $http.get(hostMac+"/api/kaizen_errors?release="+release+"&product="+product,hedrs)
        .success(function (response) {
            $scope.build_number = response.builds.build_number;
            $scope.time = response.builds.time;
            $scope.eventsThorErrors = response.builds.event_Thor_Errors; 
            $scope.eventsHDProductError = response.builds.event_HD_Product_Errors; 
			
			drawChart($scope.eventsThorErrors, 'all_Thor_errors_piechart', "Overall Thor Error Distribution");
			drawChart($scope.eventsHDProductError, 'all_HD_errors_piechart', "Overall HD Error Distribution");
        });    
    };
    
	$scope.getErrorsData(($scope.selectedRelease).trim() , ($scope.selectedProduct).trim())
    
    $scope.getErrorsList = function($event){
        $scope.selectedRelease = ($($event.target).html()).trim();
		$scope.getErrorsData(($scope.selectedRelease).trim() , ($scope.selectedProduct).trim());
    };

    $scope.getErrorsListForProduct = function($event){
        $scope.selectedProduct = ($($event.target).html()).trim();
        $scope.getErrorsData(($scope.selectedRelease).trim() , ($scope.selectedProduct).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = [ "We are using ETS as the database to gather this information.",
                        "This is based on lbsWorkflowID, i.e. it is based on distinct sessions.",
                        "We are using timeframe as CC launch date (2016-02-09) till last refresh. ",
                        "Limiting the number of errors to top 20, based on occurrence.",
                        "Errors: This contains the exact value being logged in ETS for ACCC_ERRORS for ERROR_CODE",
                        "Error Type: This contains the exact value being logged in ETS for Error_type in ETS"]
    
    $scope.displayEvents = [].concat($scope.events);
    
});


dashboard.controller('kaizenDetailsController', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.thorReleasesList = kaizenReleases;
    $scope.selectedRelease = $scope.thorReleasesList[0]
    
    $scope.getDataFromServer = function(release){
        $http.get(hostMac+"/api/kaizen_detailed_info?release="+release,hedrs)
        .success(function (response) {
            $scope.time = response.time
            $scope.details = response.details
        });
    };
    $scope.getDataFromServer($scope.selectedRelease);
    
    $scope.getReleaseData = function($event) {
        $scope.selectedRelease = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedRelease).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions =["We are using ETS as the database to gather this information.",
                        "This is based on Session_ID, i.e. it is based on distinct sessions.",
                        "Size mentioned is based the metadata of GM builds posted via FFC. This is hardcoded data as this would not change. ",
                        "For Products for which CC 2014 is being shown as “zero”, means no new version was posted for CC 2015 release, hence the last available version size is being shown under CC 2015 tab.",
                        "Download Success and Download Cancel refer to CC 2015 Version and not older.",
                        "We are using timeframe as CC launch date (2016-02-09) till last refresh for Download Success and Download Cancel. ",
                        "Download Success: No of Download end/Download Started",
                        "CC Products Cancellation: (Number of DOWNLOAD_CANCELED + Number of Install Cancelled) / Download Started"]

    $scope.displayDetails = [].concat($scope.details);
});

dashboard.controller('hostFileFix', function($scope, $http, $filter, $location, $anchorScroll) {
	$scope.thorBuildsList = thorBuildsForHostFileFix;
    $scope.selectedBuild = $scope.thorBuildsList[0]
    
    $scope.getDataFromServer = function(buildNumber){
        $http.get(hostMac+"/api/hostfileclicked?buildNumber=" + buildNumber, hedrs)
        .success(function (response) {
            $scope.all = response;
        });
    };
	$scope.all = "";
    $scope.getDataFromServer($scope.selectedBuild);
    
    $scope.getBuildData = function($event){
        $scope.selectedBuild = ($($event.target).html()).trim();
        $scope.getDataFromServer(($scope.selectedBuild).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = [ "We are using ETS as the database to gather this information",
                        "This is based on lbsworkfFlowID, i.e. it is based on distinct workflows", 
                        "We are using the build number to ascertain the range, not time frame"]
    
   
});
dashboard.controller('NotificationsBadging', function($scope, $http, $filter, $location, $anchorScroll) {
	$scope.thorBuildsList = thorBuildsForNotificationBadging;
    $scope.selectedBuild = $scope.thorBuildsList[0]
    
    $scope.getDataFromServer = function(buildNumber){
        $http.get(hostMac+"/api/NotificationsClicked?buildNumber=" + buildNumber, hedrs)
        .success(function (response) {
            $scope.all = response;
        });
    };
	$scope.all = "";
    $scope.getDataFromServer($scope.selectedBuild);
    
    $scope.getBuildData = function($event){
        $scope.selectedBuild = ($($event.target).html()).trim();
        $scope.getDataFromServer(($scope.selectedBuild).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = [ "We are using ETS as the database to gather this information",
                        "This is based on lbsworkfFlowID, i.e. it is based on distinct workflows", 
                        "We are using the build number to ascertain the range, not time frame"]
    
   
});

dashboard.controller('CampaignAnalytics', function($scope, $http, $filter, $location, $anchorScroll) {
    
    $scope.getDataFromServer = function(buildNumber){
        $http.get(hostMac+"/api/NotificationsCampaigns?buildNumber=" + buildNumber, hedrs)
        .success(function (response) {
            $scope.all = response;
            $scope.events = response;
         /*   var data = [];
            for(var key in response.NotificationReceipt) {
                var row = {};
                row.subtype = key;
                row.receipt = response.NotificationReceipt[key];
                row.homeView = response.NotificationHomeView[key];
                row.osView = response.NotificationOSToastView[key];
                row.homeAction = response.NotificationHomeAction[key];
                row.osAction = response.NotificationOSToastAction[key];
                data.push(row);
                console.log("Nitin Data action: " + row["homeAction"] );
            }
            
            $scope.displayEvents = [].concat(data); */
        });
    };
	$scope.all = "";
    $scope.getDataFromServer('Campaign');
    
  //  $scope.getBuildData = function($event){
  //      $scope.selectedBuild = ($($event.target).html()).trim();
  //      $scope.getDataFromServer(($scope.selectedBuild).trim());
  //  };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.assumptions = [ "We are using ETS as the database to gather this information",
                        "This is based on lbsworkfFlowID, i.e. it is based on distinct workflows", 
                        "We are using the build number to ascertain the range, not time frame"]

   
});

dashboard.controller('hd2SuccessController', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.thorReleasesList = hdThorReleases;
    $scope.selectedRelease = $scope.thorReleasesList[0]
    $scope.isTier1 = false;
    $scope.isMaxVersion = false;
    
    $scope.getDataFromServer = function(release,isTier1,isMaxVersion){
        $http.get(hostMac+"/api/hd2apps_success_info?release="+release+"&isTier1="+isTier1+"&isMaxVersion="+isMaxVersion,hedrs)
        .success(function (response) {
            $scope.time = response.time           
            
            for(var i = 0; i < response.details.length; i++) 
            {
                var obj = response.details[i];
                if(obj.ACCC_DL_START == undefined)
                {
                    response.details.splice(i,1);
                }	
            }            
            $scope.details = response.details
        });
    };
    $scope.getDataFromServer($scope.selectedRelease,$scope.isTier1,$scope.isMaxVersion);
    
    $scope.getReleaseData = function($event) {
        $scope.selectedRelease = $($event.target).html()
        $scope.areCheckboxEnabled()
        $scope.getDataFromServer(($scope.selectedRelease).trim(),$scope.isTier1,$scope.isMaxVersion);
    };
    $scope.areCheckboxEnabled = function() {
        var ver = ($scope.selectedRelease).trim();
        if(ver >= '4.3.0.256')
        {
            return true;
        }
        else
        {
            $scope.isTier1 = false;
            $scope.isMaxVersion = false;
            return false;
        }
        
    }
    
    $scope.checkIsTier1 = function(check) {
        
        if(check == false)
        {
           $scope.isTier1 = false; 
        }
        else
        {
           $scope.isTier1 = true; 
        }
        
        $scope.getDataFromServer(($scope.selectedRelease).trim(),$scope.isTier1,$scope.isMaxVersion);
    };
    
    $scope.showOnlyMaxVersion = function(check) {
        
        if(check == false)
        {
           $scope.isMaxVersion = false; 
        }
        else
        {
           $scope.isMaxVersion = true; 
        }
        
        $scope.getDataFromServer(($scope.selectedRelease).trim(),$scope.isTier1,$scope.isMaxVersion);
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.shouldProductToBeShow = function(name)
    {
        if(name == 'COSY')
        {        
            return false;
        }
        return true;
    };
    
    $scope.assumptions =["We are using ETS as the database to gather this information.",
                        "This is based on Session_ID, i.e. it is based on distinct sessions.",
                        "Size mentioned is based the metadata of GM builds posted via FFC. This is hardcoded data as this would not change. ",
                        "For Products for which CC 2014 is being shown as “zero”, means no new version was posted for CC 2015 release, hence the last available version size is being shown under CC 2015 tab.",
                        "Download Success and Download Cancel refer to CC 2015 Version and not older.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh for Download Success and Download Cancel. ",
                        "Download Success: No of Download end/Download Started",
                        "CC Products Cancellation: (Number of DOWNLOAD_CANCELED + Number of Install Cancelled) / Download Started"]

    $scope.displayDetails = [].concat($scope.details);
});

dashboard.controller('hd3SuccessController', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.thorReleasesList = hdThorReleases;
    $scope.selectedRelease = $scope.thorReleasesList[0]
    $scope.isTier1 = false;
    $scope.isMaxVersion = false;
    $scope.currVisibility = {};
    
    $scope.getDataFromServer = function(release,isTier1,isMaxVersion){
        $http.get(hostMac+"/api/hd3apps_success_info?release="+release+"&isTier1="+isTier1+"&isMaxVersion="+isMaxVersion,hedrs)
        .success(function (response) {
            $scope.time = response.time           
            
            for(var i = 0; i < response.details.length; i++) 
            {
                var obj = response.details[i];
                response.details[i].id = i;
                $scope.currVisibility[i] = false;
                if(obj.ACCC_DL_START == undefined)
                {
                    response.details.splice(i,1);
                }	
            }            
            $scope.details = response.details
        });
    };
    $scope.getDataFromServer($scope.selectedRelease,$scope.isTier1,$scope.isMaxVersion);
    
    $scope.getReleaseData = function($event) {
        $scope.selectedRelease = $($event.target).html()
        $scope.areCheckboxEnabled()
        $scope.getDataFromServer(($scope.selectedRelease).trim(),$scope.isTier1,$scope.isMaxVersion);
    };
    $scope.areCheckboxEnabled = function() {
        var ver = ($scope.selectedRelease).trim();
        if(ver >= '4.3.0.256')
        {
            return true;
        }
        else
        {
            $scope.isTier1 = false;
            $scope.isMaxVersion = false;
            return false;
        }
        
    }
    
    $scope.checkIsTier1 = function(check) {
        
        if(check == false)
        {
           $scope.isTier1 = false; 
        }
        else
        {
           $scope.isTier1 = true; 
        }
        
        $scope.getDataFromServer(($scope.selectedRelease).trim(),$scope.isTier1,$scope.isMaxVersion);
    };
    
    $scope.showOnlyMaxVersion = function(check) {
        
        if(check == false)
        {
           $scope.isMaxVersion = false; 
        }
        else
        {
           $scope.isMaxVersion = true; 
        }
        
        $scope.getDataFromServer(($scope.selectedRelease).trim(),$scope.isTier1,$scope.isMaxVersion);
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.shouldProductToBeShow = function(name)
    {
        if(name == 'COSY')
        {        
            return false;
        }
        return true;
    };
    
    $scope.toggleVisibility = function(id)
    {
        $scope.currVisibility[id] = ($scope.currVisibility[id] ==true)?false:true;
    }
    
    $scope.assumptions =["We are using ETS as the database to gather this information.",
                        "This is based on Session_ID, i.e. it is based on distinct sessions.",
                        "Size mentioned is based the metadata of GM builds posted via FFC. This is hardcoded data as this would not change. ",
                        "For Products for which CC 2014 is being shown as “zero”, means no new version was posted for CC 2015 release, hence the last available version size is being shown under CC 2015 tab.",
                        "Download Success and Download Cancel refer to CC 2015 Version and not older.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh for Download Success and Download Cancel. ",
                        "Download Success: No of Download end/Download Started",
                        "CC Products Cancellation: (Number of DOWNLOAD_CANCELED + Number of Install Cancelled) / Download Started"]

    $scope.displayDetails = [].concat($scope.details);
});


dashboard.controller('hd2UpdatesSuccessController', function($scope, $http, $filter, $location, $anchorScroll) {
    $scope.thorReleasesList = thorReleasesForHDUpdates;
    $scope.selectedRelease = $scope.thorReleasesList[0]
    
    $scope.getDataFromServer = function(release){
        $http.get(hostMac+"/api/hd2apps_updates_success_info?release="+release,hedrs)
        .success(function (response) {
            $scope.time = response.time
            $scope.details = response.details
        });
    };
    $scope.getDataFromServer($scope.selectedRelease);
    
    $scope.getReleaseData = function($event) {
        $scope.selectedRelease = $($event.target).html()
        $scope.getDataFromServer(($scope.selectedRelease).trim());
    };
    
    $scope.scrollTo = function(id) {
        var scrollToPos = $("#" + id).position().top;
        $(window).scrollTop(scrollToPos);
    }
    
    $scope.shouldProductToBeShow = function(name)
    {
        if(name == 'COSY')
        {        
            return false;
        }
        return true;
    };
    
    $scope.assumptions =["We are using ETS as the database to gather this information.",
                        "This is based on Session_ID, i.e. it is based on distinct sessions.",
                        "Size mentioned is based the metadata of GM builds posted via FFC. This is hardcoded data as this would not change. ",
                        "For Products for which CC 2014 is being shown as “zero”, means no new version was posted for CC 2015 release, hence the last available version size is being shown under CC 2015 tab.",
                        "Download Success and Download Cancel refer to CC 2015 Version and not older.",
                        "We are using timeframe as CC launch date (2015-06-16) till last refresh for Download Success and Download Cancel. ",
                        "Download Success: No of Download end/Download Started",
                        "CC Products Cancellation: (Number of DOWNLOAD_CANCELED + Number of Install Cancelled) / Download Started"]

    $scope.displayDetails = [].concat($scope.details);
});

dashboard.controller('coreSyncController', function($scope, $http, $filter, $location, $anchorScroll) {
    
    var CoreSyncWorkflow = ["Install", "Update"];
    
    $scope.coreSyncReleaseList = CoreSyncReleases;
    $scope.selectedRelease = $scope.coreSyncReleaseList[0];
	
    $scope.coreSyncWorkflowList = CoreSyncWorkflow;
    $scope.selectedWorkflow = $scope.coreSyncWorkflowList[0];
    
    var allEvents;
    
    //latest coresync data
	var dateRecords = [];
    var syncStartRecords = [];
    var syncSuccessRecords = [];
    var syncPercentage = [];            
    
    $scope.getErrorDataFromServer = function(release, workflow){
        
        $http.get(hostMac+"/api/coreSyncErrors?release="+release+"&workflow="+workflow,hedrs)
        .success(function (response) {
            $scope.time = response.time
            $scope.error_details = response.error_details;        
        });
    };
    
    $scope.getCoreSyncInstallDataFromServer = function(){
        
        $http.get(hostMac+"/api/coresyncinstall_success", hedrs)
        .success(function (response) {
            $scope.time = response.time;
            $scope.installDetails = response.installDetails;
            $scope.getCoreSyncUpdateDataFromServer();
            
        });             
    };
    
    $scope.getCoreSyncUpdateDataFromServer = function(){
        
        $http.get(hostMac+"/api/coresyncupdate_success", hedrs)
        .success(function (response) {            
            $scope.time = response.time;
            $scope.updateDetails = response.updateDetails;            
            $scope.getErrorDataFromServer($scope.selectedRelease, $scope.selectedWorkflow);
        });             
    };
    
    $scope.getDataFromServer = function(){
        $http.get(hostMac+"/api/coresync_success", hedrs)
        .success(function (response) {
            $scope.time = response.time;
            allEvents = response.SyncDetails;
            
            for(var i=0; i<allEvents.length; i++)
            {
                var obj = allEvents[i];
                dateRecords.push(obj["date"]);
                syncStartRecords.push(obj["ACCC_FILES_SYNC_START"]);
                syncSuccessRecords.push(obj["ACCC_FILES_SYNC_SUCCESS"]);  
                syncPercentage.push(obj["syncPercent"]);                
            }
        
            $scope.date = dateRecords;
	        $scope.fileSyncStart = syncStartRecords;
            $scope.fileSyncSuccess = syncSuccessRecords;
            $scope.syncPercentage = syncPercentage;
            $scope.getCoreSyncInstallDataFromServer();
        });             
    };
    $scope.getDataFromServer();    
    
    $scope.shouldVersionToBeShow = function(version)
    {        
        if(CoreSyncReleases.indexOf(version) == -1)
        {
            return false;
        }
       
        return true;
    };
    
    $scope.getReleaseData = function($event) {
        $scope.selectedRelease = $($event.target).html()
        $scope.getErrorDataFromServer(($scope.selectedRelease).trim(), ($scope.selectedWorkflow).trim());
    };

    $scope.getWorkflowData = function($event) {
        $scope.selectedWorkflow = $($event.target).html()
        $scope.getErrorDataFromServer(($scope.selectedRelease).trim(), ($scope.selectedWorkflow).trim());
    };
    
    
});

dashboard.controller('ccxController', function($scope, $http, $filter, $location, $anchorScroll) {
    
    var CCXWorkflow = ["Install", "Update"];
    
    $scope.ccxReleaseList = CCXReleases;
    $scope.selectedRelease = $scope.ccxReleaseList[0];
	
    $scope.ccxWorkflowList = CCXWorkflow;
    $scope.selectedWorkflow = $scope.ccxWorkflowList[0];       
    
    $scope.getErrorDataFromServer = function(release, workflow){
        
        $http.get(hostMac+"/api/ccxErrors?release="+release+"&workflow="+workflow,hedrs)
        .success(function (response) {
            $scope.time = response.time
            $scope.error_details = response.error_details;        
        });
    };
    
    $scope.getCCXInstallDataFromServer = function(){
        
        $http.get(hostMac+"/api/ccxInstall", hedrs)
        .success(function (response) {
            $scope.time = response.time;
            $scope.installDetails = response.installDetails;
            $scope.getErrorDataFromServer($scope.selectedRelease, $scope.selectedWorkflow);
            
        });             
    };
    
     $scope.getCCXInstallDataFromServer();
//    $scope.getCoreSyncUpdateDataFromServer = function(){
//        
//        $http.get(hostMac+"/api/coresyncupdate_success", hedrs)
//        .success(function (response) {            
//            $scope.time = response.time;
//            $scope.updateDetails = response.updateDetails;            
//            $scope.getErrorDataFromServer($scope.selectedRelease, $scope.selectedWorkflow);
//        });             
//    };    
    
    $scope.shouldVersionToBeShow = function(version)
    {        
        if(CCXReleases.indexOf(version) == -1)
        {
            return false;
        }
       
        return true;
    };
    
    $scope.getReleaseData = function($event) {
        $scope.selectedRelease = $($event.target).html()
        $scope.getErrorDataFromServer(($scope.selectedRelease).trim(), ($scope.selectedWorkflow).trim());
    };

    $scope.getWorkflowData = function($event) {
        $scope.selectedWorkflow = $($event.target).html()
        $scope.getErrorDataFromServer(($scope.selectedRelease).trim(), ($scope.selectedWorkflow).trim());
    };
    
    
});

dashboard.controller('cclibraryController', function($scope, $http, $filter, $location, $anchorScroll) {
    
    var CCLibraryWorkflow = ["Install", "Update"];
    
    $scope.cclibraryReleaseList = CCLibraryReleases;
    $scope.selectedRelease = $scope.cclibraryReleaseList[0];
	
    $scope.cclibraryWorkflowList = CCLibraryWorkflow;
    $scope.selectedWorkflow = $scope.cclibraryWorkflowList[0];
    
    $scope.getCCLibraryInstallDataFromServer = function(){
        
        $http.get(hostMac+"/api/cclibraryInstall", hedrs)
        .success(function (response) {
            $scope.time = response.time;
            $scope.installDetails = response.installDetails;
            $scope.getCCLibraryUpdateDataFromServer();
            
        });             
    };    

    $scope.getCCLibraryUpdateDataFromServer = function(){
        
        $http.get(hostMac+"/api/cclibraryUpdate", hedrs)
        .success(function (response) {            
            $scope.time = response.time;
            $scope.updateDetails = response.updateDetails;            
            $scope.getErrorDataFromServer($scope.selectedRelease, $scope.selectedWorkflow);
        });             
    };    
    
    $scope.getErrorDataFromServer = function(release, workflow){
        
        $http.get(hostMac+"/api/cclibraryErrors?release="+release+"&workflow="+workflow,hedrs)
        .success(function (response) {
            $scope.time = response.time
            $scope.error_details = response.error_details;        
        });
    };
    
    $scope.getCCLibraryInstallDataFromServer();
    
    $scope.shouldVersionToBeShow = function(version)
    {        
        if(CCLibraryReleases.indexOf(version) == -1)
        {
            return false;
        }
       
        return true;
    };
    
    $scope.getReleaseData = function($event) {
        $scope.selectedRelease = $($event.target).html()
        $scope.getErrorDataFromServer(($scope.selectedRelease).trim(), ($scope.selectedWorkflow).trim());
    };

    $scope.getWorkflowData = function($event) {
        $scope.selectedWorkflow = $($event.target).html()
        $scope.getErrorDataFromServer(($scope.selectedRelease).trim(), ($scope.selectedWorkflow).trim());
    };
    
    
});