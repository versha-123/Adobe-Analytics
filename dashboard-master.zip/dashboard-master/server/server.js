var express = require('express')
var mysql = require('mysql');
var app = express()
var fs = require('fs');
var jQuery = require('jquery');
var deferred = require('deferred');
var xlsxj = require("xlsx-to-json");
var path = require("path");
var config = require("./config/config.json");
var passport = require('passport');
var bodyParser = require('body-parser');
var LdapStrategy = require('passport-ldapauth');
var constants =  require('./lib/utils/constants.js');
var logger = require('./lib/log/log.js');

app.disable('etag')
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

/*
var OPTS = {
  server: {
    url: 'ldaps://SJCAD-VIP.CORP.ADOBE.COM:636',
    //bindDn: 'cn=bugatti,cn=Users,dc=adobenet,dc=global,dc=adobe,dc=com',
    adminDn: 'cn=bugatti,cn=Users,dc=adobenet,dc=global,dc=adobe,dc=com',
	//bindCredentials: 'BUG@ttip201507',
	adminPassword: 'BUG@ttip201507',
    searchBase: 'DC=adobenet,DC=global,DC=adobe,DC=com',
    searchFilter: '(&(objectcategory=person)(objectclass=user)(|(samaccountname={{username}})(mail={{username}})))',
	searchAttributes: ['displayName', 'mail']
  }
};

passport.use(new LdapStrategy(OPTS));
app.use(passport.initialize());

*/

var routes = require("./lib/routes");
routes(app);

var server = app.listen(3000, function () {
  var host = server.address().address
  var port = server.address().port
  console.log('Listening at http://%s:%s', host, port);
  logger.info('Listening at http://%s:%s', host, port);
})
