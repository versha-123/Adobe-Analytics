var fs = require('fs');
var csvToJson = require('convert-csv-to-json');
var mysql = require('mysql');
var Promise = require('promise');
var Q = require("q");
var constants = require('./constants.js');

//Constants
var folderPath = constants.folderPath;

//Functions
function connectToLocalDB(queryString){
	var connection = mysql.createConnection('mysql://root:root@localhost:3006/thordashboard');
	connection.connect();
	connection.query(queryString, function(err1) {
		if (err1){
			console.log("Error"+err1);
		}
		else{
			//console.log("Local Database updated successfully... ");
		}
	});
	connection.end();
};

/*
	This function creates a custom query for updating ETS data in local database
	@param buildNumber		[IN]The Thor build number for which data is to be inserted in database
	@param JsonStr			[IN]The json text which needs to inserted in database
	@param query_type		[IN]The query_type for which data needs to be inserted in database
*/
function updateLocalDB(buildNumber, JsonStr, query_type){
	var queryString =  'INSERT INTO analytics_data (build_no,data,query_type) VALUES(\''+buildNumber+'\',\''+JsonStr+'\',\''+query_type+'\') ON DUPLICATE KEY UPDATE  data=\''+JsonStr+'\', timestamp = CURRENT_TIMESTAMP' ;
	connectToLocalDB(queryString);
	console.log("Done for : ", buildNumber, " with query_type : ", query_type)
}

function readFiles(dirname, outFilename, onError) {
  fs.readdir(dirname, function(err, filenames) {
    if (err) {
      onError(err);
      return;
    }
    filenames.forEach(function(filename) {
			outFilename(filename);
    });
  });
}

function mainFun()
{
	console.log("Test js started")
	readFiles(folderPath, function(filename) {
		queryFullName = filename.substring(0,filename.length - 4);
		queryParts = queryFullName.split("#");
		
		var json = csvToJson.fieldDelimiter(',').getJsonFromCsv(folderPath + filename);
		var data = JSON.stringify(json);
		//console.log(data);		

		updateLocalDB(queryParts[1],data,queryParts[0]);
		//updateLocalDB("4.0.1.188",data,queryParts[0]);
		//queryParts[0] has query name, queryParts[1] has build number
	}, function(err) {
	  throw err;
	});

}

mainFun();
