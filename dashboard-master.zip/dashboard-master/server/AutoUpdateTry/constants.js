module.exports = {
    folderPath: 'C:\\server\\AutoUpdateTry\\csvDownloaded\\'	
}
