module.exports = {
    folderPath: 'C:\\server\\Release\\4.6\\csvDownloaded\\'	
}
