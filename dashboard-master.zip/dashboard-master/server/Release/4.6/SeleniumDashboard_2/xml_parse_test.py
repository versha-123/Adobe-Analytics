'''
Created on 9 Aug 2018

@author: rewari
'''

import os,time, glob, datetime
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import StaleElementReferenceException
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from xml.etree import ElementTree as ET
import subprocess
import os

def getTimeStamp():
	timestampInSecs = time.time()
	timestamp = datetime.datetime.fromtimestamp(timestampInSecs).strftime('%Y-%m-%d-%H-%M-%S-%f')
	return timestamp

if __name__== "__main__":
	try:		
		
		DownloadsFolderLocation = 'C:\\Users\\labuser\\Downloads\\*.csv'
		OutputFolderLocation = 'C:\\server\\4.6\\SeleniumDashboard_2\\csvDownloaded\\'
		#Main ETSAutomatedResults will be created only when script is run for the first time
		if not os.path.exists(OutputFolderLocation):
			os.mkdir(OutputFolderLocation)
			
		#Results folder will be created each time script is run. Timestamp used to ensure unique name.		
		# OutputFolderLocation = os.path.join(OutputFolderLocation, 'Results_'+(getTimeStamp()))
		# os.mkdir(OutputFolderLocation)
		print 'Files will be scanned from default download location : ' + DownloadsFolderLocation + ' and moved to Results output folder' + OutputFolderLocation
		file_query_log = open('query_log.txt','w')
		file_error_log = open('error_log.txt','w')
		path_xml=".\\test_folder\\"
		for filename in glob.glob(os.path.join(path_xml, '*.xml')):
			print "now processing file "+ filename
			queriesListXML = ET.parse(filename)
			root = queriesListXML.getroot()
			allQueryObjects= root.findall(".//query_object")
			etsTableName=root.find("query_tableName").text
			accBuildNumber=root.find("query_accBuildNumber").text
			insertdts=root.find("query_insertdts").text
			
			for queryObject in allQueryObjects:
				try:
					queryName = queryObject.find(".//query_name").text
					querySQL = queryObject.find(".//query_sql").text.format(**vars())
					print "Found element Query Name in XML with value: " + queryName
					print "Found element Query SQL in XML with value: " + querySQL
					file_query_log.write(querySQL)
					file_query_log.write("\n")
					
					print "CSV file downloaded to downloads folder. Moving it to results folder"
					
					
				except Exception,e:
					temp_error="Exception occurred while running query : " + queryName + " with SQL : " + querySQL + " and error message : " + str(e)
					print temp_error
					file_error_log.write(temp_error)
					file_error_log.write("\n")
					print "Moving on to next query"
					
		print "Script End"
		
		driver.close()
		
		file_query_log.close()
		file_error_log.close()


	except Exception,e:
		print "Exception occurred in ETS UI Automation Script"
		print str(e)

