'''
Created on 9 Aug 2018

@author: rewari
'''

import os,time, glob, datetime
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import StaleElementReferenceException
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from xml.etree import ElementTree as ET
import subprocess
import os
 
def getTimeStamp():
	timestampInSecs = time.time()
	timestamp = datetime.datetime.fromtimestamp(timestampInSecs).strftime('%Y-%m-%d-%H-%M-%S-%f')
	return timestamp

def logMessage(message):	
	print message
	logFile = open('log.txt','a+')
	logFile.write(message)
	logFile.write("\n")
	logFile.close()
	
if __name__== "__main__":
	try:
		logFile = open('log.txt','w')
		logFile.close()
		logMessage("Starting ETS UI Automation Script")
		chromedriver = os.path.dirname(__file__)+os.sep+'chromedriver.exe'
		logMessage("driver initialized")
		driver = webdriver.Chrome()
		driver.get("https://ets-ui.services.adobe.com/superset/sqllab")
		logMessage "Waiting to login"
		WebDriverWait(driver,600).until(EC.presence_of_element_located((By.XPATH,"//h2[text()[contains(.,'Dashboards')]]")))
		print "Login wait completed. Reloading to required page"
		
		#Get required page after login
		driver.get("https://ets-ui.services.adobe.com/superset/sqllab")
		
		WebDriverWait(driver,60).until(EC.presence_of_element_located((By.CSS_SELECTOR,"#brace-editor")))
		logMessage("Page load completed")
		time.sleep(5)
		#Select DataBase
		#driver.find_element_by_xpath("//div[text()[contains(.,'Select a database')]]").click()
		driver.find_element_by_xpath("//*[text()[contains(.,'Database')]]").click()
		
		
		
		time.sleep(5)
		driver.find_element_by_xpath("//*[text()[contains(.,'redshift_prod')]]").click()
		logMessage("database selected")

		#Select Schema
		time.sleep(2)
		driver.find_element_by_xpath("//div[text()[contains(.,'Select a schema')]]").click()
		time.sleep(5)
		driver.find_element_by_xpath("//*[text()[contains(.,'public')]]").click()
		logMessage("schema selected"
		
		'''
		Process XML file and run queries
		'''
		DownloadsFolderLocation = 'C:\\Users\\labuser\\Downloads\\*.csv'
		OutputFolderLocation = 'C:\\server\\4.6\\SeleniumDashboard_2\\csvDownloaded\\'
		#Main ETSAutomatedResults will be created only when script is run for the first time
		if not os.path.exists(OutputFolderLocation):
			os.mkdir(OutputFolderLocation)
			
		#Results folder will be created each time script is run. Timestamp used to ensure unique name.		
		# OutputFolderLocation = os.path.join(OutputFolderLocation, 'Results_'+(getTimeStamp()))
		# os.mkdir(OutputFolderLocation)
		logMessage('Files will be scanned from default download location : ' + DownloadsFolderLocation + ' and moved to Results output folder' + OutputFolderLocation
		
		
		path_xml=".\\xml_collections\\"
		for filename in glob.glob(os.path.join(path_xml, '*.xml')):
			logMessage("now processing file "+ filename
			queriesListXML = ET.parse(filename)
			root = queriesListXML.getroot()
			allQueryObjects= root.findall(".//query_object")
			etsTableName=root.find("query_tableName").text
			accBuildNumber=root.find("query_accBuildNumber").text
			insertdts=root.find("query_insertdts").text
			productId_root=root.find("query_productid")
			
			if productId_root!=None:
				productId=productId_root.text
			
			textAreaForQueryFrame = driver.find_elements_by_id("brace-editor")
			textAreaForQuery = driver.find_element_by_tag_name("textarea")
			textAreaForQuery.clear()
			
			for queryObject in allQueryObjects:
				try:
					file_query_log.write("------------------------------------------------------------------------------------\n")
					queryName = queryObject.find(".//query_name").text
					querySQL = queryObject.find(".//query_sql").text.format(**vars())
					logMessage("Found element Query Name in XML with value: " + queryName
					logMessage("Found element Query SQL in XML with value: " + querySQL
					file_query_log.write(queryName + "\n")
					file_query_log.write(querySQL + "\n")
					time.sleep(2)
					textAreaForQuery.send_keys(Keys.CONTROL +'a')
					time.sleep(2)
					textAreaForQuery.send_keys(Keys.DELETE)
					time.sleep(2)
					# text_area_val = textAreaForQuery.getAttribute('value')
					# time.sleep(2)
					# file_textarea.write(text_area_val)
					# file_textarea.write("\n")
					textAreaForQuery.send_keys(querySQL)
					time.sleep(2)
					logMessage("Query sent to TextArea"
					driver.find_element_by_xpath("//button[text()[contains(.,'Run Query')]]").click()
					time.sleep(2)
					logMessage("Query run clicked. Waiting for query to be completed. Time out 3600 seconds."
					WebDriverWait(driver,3600).until(EC.presence_of_element_located((By.XPATH,"//a[text()[contains(.,'CSV')]]")))
					time.sleep(2)
					driver.find_element_by_xpath("//a[text()[contains(.,'CSV')]]").click()
					logMessage("CSV file downloaded to downloads folder. Moving it to results folder"
					# file_query_log.write(queryName+" CSV file downloaded to downloads folder. Moving it to results folder \n")
					listOfFiles = glob.glob(DownloadsFolderLocation) # * means all, we need specific format then *.csv
					
					#note: 'getmtime' returns last modified time and 'getctime' gets creation time.
					latestFileInDownload = max(listOfFiles, key=os.path.getmtime)
					
					#Timestamp is used to prevent duplicate file exceptions
					filenameToSaveFileAs=queryName+"#"+accBuildNumber
					ResultFilePath = os.path.join(OutputFolderLocation,filenameToSaveFileAs +'.csv')
					
					#Rename and move file to output folder
					if os.path.exists(ResultFilePath):
						os.remove(ResultFilePath)
					file_query_log.write(latestFileInDownload + " is renaming to " + ResultFilePath + "\n")
					os.rename(latestFileInDownload,ResultFilePath)
					
					if not os.path.exists(latestFileInDownload) and os.path.exists(ResultFilePath):
						logMessage(" File successfully moved"
						file_query_log.write("File successfully moved\n")
					else:
						logMessage("Some error occurred in moving file to results folder"
						file_query_log.write("Some error occurred in moving file to results folder\n")
					
					#command = "node test.js"
					#commandOutput = subprocess.Popen(command, shell = True , stdout = subprocess.PIPE).stdout.read()
					#logMessage(commandOutput
			
				except Exception,e:
					temp_error="Exception occurred while running query : " + queryName + " with SQL : " + querySQL + " and error message : " + str(e)
					logMessage(temp_error
					file_error_log.write(temp_error)
					file_error_log.write("\n")
					logMessage("Moving on to next query"
					
		logMessage("Script End"
		
		driver.close()
		
		file_query_log.close()
		file_error_log.close()


	except Exception,e:
		logMessage("Exception occurred in ETS UI Automation Script"
		logMessage(str(e)

