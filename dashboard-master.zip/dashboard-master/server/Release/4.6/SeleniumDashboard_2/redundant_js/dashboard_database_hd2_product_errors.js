var pg = require("pg");
var express = require('express')
var fs = require('fs');
var app = express()
var mysql = require('mysql');
app.disable('etag')
var events = require('events');
var EventEmitter = events.EventEmitter;
var flowController = new EventEmitter();
var async = require('async');
var Step = require('step');
var Promise = require('promise');
var Q = require("q");
/*
	This function connects to local database and runs the required input query
	@param queryString		[IN]The query which needs to be performed on local database
*/
function connectToLocalDB(queryString){
	var connection = mysql.createConnection('mysql://root:root@localhost:3006/thordashboard');
	connection.connect();
	connection.query(queryString, function(err1) {
		if (err1){
			console.log("Error"+err1);
		}
		else{
			//console.log("Local Database updated successfully... ");
		}
	});		 
	connection.end();
};

/*
	This function creates a custom query for updating ETS data in local database 
	@param buildNumber		[IN]The Thor build number for which data is to be inserted in database
	@param JsonStr			[IN]The json text which needs to inserted in database
	@param query_type		[IN]The query_type for which data needs to be inserted in database
*/
function updateLocalDB(buildNumber, JsonStr, query_type){
	var queryString =  'INSERT INTO analytics_data (build_no,data,query_type) VALUES(\''+buildNumber+'\',\''+JsonStr+'\',\''+query_type+'\') ON DUPLICATE KEY UPDATE  data=\''+JsonStr+'\', timestamp = CURRENT_TIMESTAMP' ;
	connectToLocalDB(queryString);
	console.log("Done for : ", buildNumber, " with query_type : ", query_type)
}




function connectToEtsDB(etsQueryString, buildNumber, query_type) {  
    var d = Q.defer();
    var conString = "postgres://anksinha:L2OLnWnRw9zG@localhost:54002/ets?ssl=true";
	var client = new pg.Client(conString);
	client.connect();
	console.log("Query is : ",etsQueryString)
	var query = client.query(etsQueryString);
	var JsonStr;
	console.log("Querying data for Thor build : ", buildNumber, " with query_type : ", query_type);
	query.on("row", function (row, result) {
		result.addRow(row);
	});

    query.on("end", function (result,err) {
	   console.log("Data Fetched");
        if(err){
		console.log("Error is ",err);
		 d.reject(err);
		}
        else {
			JsonStr=JSON.stringify(result.rows);
			//console.log(JsonStr);
			console.log("Json retrieved....")
			if (query_type=='conf_process' || query_type=='v1.conflicting.process.cc2015' || query_type=='v2.conf.proc.in.cc2015' || query_type=='v2.conf.proc.dl.cc2015'){
				//This hard coding is required as the data received from ETS for this query contains special characters which gives error while inserting in mysql
				var JsonStrNew = JsonStr.replace(/'/g, "''")
				JsonStr = JsonStrNew
			}
			console.log("Updating Local DB")			
			updateLocalDB(buildNumber, JsonStr, query_type)
			console.log("Updated Local DB")			
			client.end();
			d.resolve(result);
        }
    });

    return d.promise;
}

function calcTime(city, offset) {
    // create Date object for current location
    var d = new Date();

    // convert to msec
    // subtract local time zone offset
    // get UTC time in msec
    var utc = d.getTime() + (d.getTimezoneOffset() * 60000);

    // create new Date object for different city
    // using supplied offset
    var nd = new Date(utc + (3600000*offset));

    // return time as a string
    return nd;
}

/*
	This function gives the local time in required format
*/
function getDateTime() {
    var date = new calcTime('Bombay', '+5.5'); 
	var hour = date.getHours();
    hour = (hour < 10 ? "0" : "") + hour;
    var min  = date.getMinutes();
    min = (min < 10 ? "0" : "") + min;
    var sec  = date.getSeconds();
    sec = (sec < 10 ? "0" : "") + sec;
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    month = (month < 10 ? "0" : "") + month;
    var day  = date.getDate();
    day = (day < 10 ? "0" : "") + day;
    return year + ":" + month + ":" + day + " at " + hour + ":" + min + ":" + sec +" IST";
}
var etsTableName = "all_ets_event_simple"

var accBuildNumber = "4.6.0.384"
var insertdts = "CAST('2018-06-25 04:00:00' AS TIMESTAMP)"



//########################### Thor build 3.4.3.%#####################################################


//************************* Query for Funnel Charts *************************************************
// Function For Build Number - 206

function queryDatabase() {
	console.log("Starting connection ")
		console.log("\n");
        console.log("---- Executing Query 1  --------");
		var hdErrors = "select json_extract_path_text(params,'Product_ID')::varchar(512) product,json_extract_path_text(params,'Error_Code')::varchar(512) errorcode,json_extract_path_text(params,'Error_Type')::varchar(512) errortype, count(distinct(user_guid)) ecount from "+etsTableName+" where code like 'ACCC_ERROR' and  json_extract_path_text(params,'ACCC_HYPERDRIVE_BUILD_PVALUE')::varchar(512) = 'HD' and json_extract_path_text(params,'ACCC_Version')::varchar(512) like '"+ accBuildNumber +"' and  insert_dts >= "+ insertdts +" and dts >= "+ insertdts +" and json_extract_path_text(params,'Product_ID')::varchar(512) NOT IN ('COSY','CCXP','LIBS') group by errorcode, errortype,json_extract_path_text(params,'Product_ID') order by ecount desc"
		var dateTime = getDateTime()
		console.log("currentTime = ", dateTime )
		console.log("\n")
		connectToEtsDB(hdErrors, accBuildNumber, "v1.hd2.product.errors")
	   
		
		 .then(function(result) {
        return result;
		})

		.then(function() {
			console.log("\n");
			console.log("---- Executing Query 2  --------");
			var hdResourceErrors = "select json_extract_path_text(params,'Product_ID')::varchar(512) product,json_extract_path_text(params,'Error_Code')::varchar(512) errorcode, count(distinct(user_guid)) ecount from "+etsTableName+" where code like 'ACCC_RESOURCE_ERROR' and  json_extract_path_text(params,'ACCC_HYPERDRIVE_BUILD_PVALUE')::varchar(512) = 'HD' and json_extract_path_text(params,'ACCC_Version')::varchar(512) like '"+ accBuildNumber +"' and  insert_dts >= "+ insertdts +" and dts >= "+ insertdts +" and json_extract_path_text(params,'Product_ID')::varchar(512) NOT IN ('COSY','CCXP') group by errorcode,json_extract_path_text(params,'Product_ID') order by ecount desc"
			var dateTime = getDateTime()
			console.log("currentTime = ", dateTime )
			console.log("\n")
			return connectToEtsDB(hdResourceErrors, accBuildNumber, "v1.hd2.product.resource.errors")
		}) 
	
    .fail(function(err) {
        console.log(err);
        return;
    });
}
queryDatabase();
var dateTime = getDateTime()
console.log("currentTime = ", dateTime )
fs.writeFile("C:\\server\\data\\Time", dateTime, function(err) {
	if(err) {
		return console.log("Failed to write dateTime in file with error :", err);
	}
	console.log("Time File saved...");
});



