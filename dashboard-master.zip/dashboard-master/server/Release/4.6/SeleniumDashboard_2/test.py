import os

path = 'C:\\Users\\labuser\\Downloads\\'
os.chdir(path)
files = sorted(os.listdir(os.getcwd()), key=os.path.getmtime)

newest = files[-1]

print "Newest:", newest