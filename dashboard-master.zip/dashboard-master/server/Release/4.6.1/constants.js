module.exports = {
    folderPath: 'C:\\server\\Release\\4.6.1\\csvDownloaded\\'	
}
