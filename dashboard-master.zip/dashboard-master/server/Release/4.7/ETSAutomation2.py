import os,time, glob, datetime
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import StaleElementReferenceException
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By

from xml.etree import ElementTree as ET
import subprocess
import os
import sys

dirPath = os.getcwd()

#UI Elements CSS & XPATH List
ETS_SQL_LAB_URL = "https://ets-ui.services.adobe.com/superset/sqllab"

DASHBOARD_HEADING_AFTER_LOGIN_XPATH="//h2[text()[contains(.,'Dashboards')]]"
SQL_QUERY_TEXTAREA_CSS = "#brace-editor"

DATABASE_SELECTOR_DIV_XPATH = "//*[text()[contains(.,'Database')]]"
REDSHIFT_LIST_ITEM_XPATH = "//*[text()[contains(.,'redshift_prod')]]"

SCHEMA_SELECTOR_DIV_XPATH = "//div[text()[contains(.,'Select a schema')]]"
PUBLIC_SCHEMA_LIST_ITEM_XPATH = "//*[text()[contains(.,'public')]]"

RUN_QUERY_BUTTON_XPATH = "//button[text()[contains(.,'Run Query')]]"
CSV_BUTTON_XPATH = "//a[text()[contains(.,'CSV')]]"

SYNTAX_ALERT_XPATH = "//div[text()[contains(.,'syntax error')]]"

def getTimeStamp():
	timestampInSecs = time.time()
	timestamp = datetime.datetime.fromtimestamp(timestampInSecs).strftime('%Y-%m-%d-%H-%M-%S-%f')
	return timestamp

def logMessage(message):	
	print message
	logFile = open('log.txt','a+')
	logFile.write(message+"\n")
	logFile.close()

def clickAndVerify(ElementString,method,driver=None,retries=5):
	counter=0
	while(counter<retries):
		try:
			time.sleep(2)
			if driver!=None:
				if method == "CSS":
					elem = driver.find_element_by_css_selector(ElementString)
				if method == "XPATH":
					elem = driver.find_element_by_xpath(ElementString)
				else:
					logMessage("Incorrect click method provide to clickAndVerify Function")
				if elem.is_displayed():
					elem.click()
					logMessage("Element Clicked : "+ElementString )
					return True
			else:
				return False
		except StaleElementReferenceException,e:
			raise Exception("Retry as it is a stale element")        
		except Exception,e:
			logMessage("Inside exception clickAndVerify for element " + ElementString + " Error Message: " + str(e))
			time.sleep(2)
		counter+=1
	return False

	
if __name__== "__main__":
	try:
		logFile = open('log.txt','w')
		logFile.close()
		
		logMessage("Starting ETS UI Automation Script")
		logMessage("driver initialized")
		chrome_options = Options()
		chrome_options.add_argument("--disable-gpu")
		driver = webdriver.Chrome(chrome_options=chrome_options)
		driver.get(ETS_SQL_LAB_URL)
		logMessage ("Waiting to login")
		WebDriverWait(driver,600).until(EC.presence_of_element_located((By.XPATH,DASHBOARD_HEADING_AFTER_LOGIN_XPATH)))
		logMessage ("Login wait completed. Reloading to required page")
		
		#Get required page after login
		driver.get(ETS_SQL_LAB_URL)
		
		WebDriverWait(driver,60).until(EC.presence_of_element_located((By.CSS_SELECTOR,SQL_QUERY_TEXTAREA_CSS)))
		logMessage("Page load completed")
		
		#Select DataBase
		clickAndVerify(DATABASE_SELECTOR_DIV_XPATH,"XPATH",driver)
		clickAndVerify(REDSHIFT_LIST_ITEM_XPATH,"XPATH",driver)
		logMessage("database selected")

		#Select Schema
		clickAndVerify(SCHEMA_SELECTOR_DIV_XPATH,"XPATH",driver)
		clickAndVerify(PUBLIC_SCHEMA_LIST_ITEM_XPATH,"XPATH",driver)
		logMessage("schema selected")
		
		'''
		Process XML file and run queries
		'''
		DownloadsFolderLocation = 'C:\\Users\\labuser\\Downloads\\*.csv'
		OutputFolderLocation = os.path.join(dirPath,'csvDownloaded')
		
		arg = sys.argv[1]
		if(arg == 'Thor'):
			logMessage("Running Thor Dashboard")
			xmlPath = os.path.join(dirPath,'thorDashboardFiles')
		elif(arg == 'HD'):
			logMessage("Running HD Dashboard")
			xmlPath = os.path.join(dirPath,'hdDashboardFiles')
		elif(arg == 'Async'):
			logMessage("Running Async Dashboard")
			xmlPath = os.path.join(dirPath,'asyncDashboardFiles')

		#Main ETSAutomatedResults will be created only when script is run for the first time
		if not os.path.exists(OutputFolderLocation):
			os.mkdir(OutputFolderLocation)
			
		#Results folder will be created each time script is run. Timestamp used to ensure unique name.		
		# OutputFolderLocation = os.path.join(OutputFolderLocation, 'Results_'+(getTimeStamp()))
		# os.mkdir(OutputFolderLocation)
		# logMessage('Files will be scanned from default download location : ' + DownloadsFolderLocation + ' and moved to Results output folder' + OutputFolderLocation)
		
		logMessage("XML Files are reading from " + xmlPath)
		for filename in glob.glob(os.path.join(xmlPath, '*.xml')):
			logMessage("--------NEW FILE STARTED----------")
			logMessage("now processing file "+ filename)
			queriesListXML = ET.parse(filename)
			root = queriesListXML.getroot()
			allQueryObjects= root.findall(".//query_object")
			etsTableName=root.find("query_tableName").text
			accBuildNumber=root.find("query_accBuildNumber").text
			insertdts=root.find("query_insertdts").text
			productIdRoot=root.find("query_productid")
			
			if productIdRoot!=None:
				productId=productIdRoot.text
			
			textAreaForQueryFrame = driver.find_element_by_css_selector(SQL_QUERY_TEXTAREA_CSS)
			textAreaForQuery = driver.find_element_by_tag_name("textarea")
			textAreaForQuery.clear()
			
			for queryObject in allQueryObjects:
				try:
					logMessage("------------------------------------------------------------------------------------")
					queryName = queryObject.find(".//query_name").text
					querySQL = queryObject.find(".//query_sql").text.format(**vars())
					logMessage("Found element Query Name in XML with value: " + queryName)
					logMessage("Found element Query SQL in XML with value: " + querySQL)
					RetryTypingQuery = True
					RetryTypingQueryCounter=0
					while(RetryTypingQuery and RetryTypingQueryCounter<5):
						#Using this flag to check if TextArea has been cleared.
						textAreaNotCleared = True
						clearCounter=0
						while(textAreaNotCleared and clearCounter<5):
							#Assumption that Text Area has been cleared
							textAreaNotCleared = False
							clearCounter+=1
							logMessage("Trying to clear TextArea. Attempt No. : " + str(clearCounter))
							time.sleep(2)
							textAreaForQuery.send_keys(Keys.CONTROL +'a')
							time.sleep(2)
							textAreaForQuery.send_keys(Keys.DELETE)
							time.sleep(2)
							for line in driver.find_elements_by_css_selector(".ace-line"):
								if line.get_attribute('innerHTML')!=None:
									#If Any text line is found
									textAreaNotCleared = True
									
						# text_area_val = textAreaForQuery.getAttribute('value')
						# time.sleep(2)
						# file_textarea.write(text_area_val)
						# file_textarea.write("\n")
						textAreaForQuery.send_keys(querySQL)
						logMessage("Query sent to TextArea")
						clickAndVerify(RUN_QUERY_BUTTON_XPATH,"XPATH",driver)
						#WebDriverWait(driver,60).until(EC.presence_of_element_located((By.XPATH,SYNTAX_ALERT_XPATH)))
						time.sleep(30)
						logMessage("check for syntax error done")
						try:
							driver.find_element_by_xpath(SYNTAX_ALERT_XPATH)
							RetryTypingQueryCounter+=1
							logMessage("Syntax error found")
						except Exception,e:
							RetryTypingQuery = False
							logMessage("element not found")
		
						# if driver.find_element_by_xpath(SYNTAX_ALERT_XPATH):
							# RetryTypingQueryCounter+=1
							# logMessage("Syntax error found")
						# else:
							# RetryTypingQuery = False
							# logMessage("Syntax error not found")

					logMessage("Query run clicked. Waiting for query to be completed. Time out 4*3600 seconds.")
					WebDriverWait(driver,14400).until(EC.presence_of_element_located((By.XPATH,RUN_QUERY_BUTTON_XPATH)))
					time.sleep(2)
					clickAndVerify(CSV_BUTTON_XPATH,"XPATH",driver)
					logMessage("CSV file downloaded to downloads folder.")
					# file_query_log.write(queryName+" CSV file downloaded to downloads folder. Moving it to results folder \n")
					downloadInProgress = True
					while(downloadInProgress):
						logMessage("Waiting for 10 seconds")
						time.sleep(10)
						listOfDownloadingFiles = glob.glob('C:\\Users\\labuser\\Downloads\\*.crdownload')
						logMessage("Checking for files being downloaded")
						#logMessage(listOfDownloadingFiles)
						if len(listOfDownloadingFiles) == 0:
							downloadInProgress = False
					logMessage("Download complete")
					listOfFiles = glob.glob(DownloadsFolderLocation) # * means all, we need specific format then *.csv
					
					#note: 'getmtime' returns last modified time and 'getctime' gets creation time.
					latestFileInDownload = max(listOfFiles, key=os.path.getmtime)
					
					#Timestamp is used to prevent duplicate file exceptions
					filenameToSaveFileAs=queryName+"#"+accBuildNumber
					ResultFilePath = os.path.join(OutputFolderLocation,filenameToSaveFileAs +'.csv')
					
					#Rename and move file to output folder
					if os.path.exists(ResultFilePath):
						os.remove(ResultFilePath)
					logMessage(latestFileInDownload + " is renaming to " + ResultFilePath)
					os.rename(latestFileInDownload,ResultFilePath)
					
					if not os.path.exists(latestFileInDownload) and os.path.exists(ResultFilePath):
						logMessage(" File successfully moved")
					else:
						logMessage("Some error occurred in moving file to results folder")
					
					command = "node localDBDump.js"
					commandOutput = subprocess.Popen(command, shell = True , stdout = subprocess.PIPE).stdout.read()
					logMessage(commandOutput)
			
				except Exception,e:
					logMessage("Exception occurred while running query : " + queryName + " with SQL : " + querySQL + " and error message : " + str(e))
					
					
		logMessage("Script End")
		
		#driver.close()


	except Exception,e:
		logMessage("Exception occurred in ETS UI Automation Script")
		logMessage(str(e))

