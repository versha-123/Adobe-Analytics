module.exports = {
    folderPath: 'C:\\server\\Release\\AsyncDashboard\\csvDownloaded\\'	
}
